#php and ajax based dropdown list of country, state and city
A simple oops based php and ajax country state city dropdown list

Technology Used: PHP, Mysql, Jquery


Demo Link: http://www.iamrohit.in/tag/php-ajax-country-state-city-dropdown

