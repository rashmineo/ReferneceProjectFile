<div class="col-md-3">
    <div class="panel panel-default panel-flush">
        <div class="panel-heading">
            Sidebar
        </div>

        <div class="panel-body">
            <ul class="nav" role="tablist">
                <li role="presentation">
                    <a href="<?php echo e(url('/admin')); ?>">
                        Dashboard
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>
