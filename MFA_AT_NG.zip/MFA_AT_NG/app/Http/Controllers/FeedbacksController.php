<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Feedback;
use Auth;
use Carbon\Carbon;
use DB;

class FeedbacksController extends Controller
{
    public function index(Request $request)
    {

    	$keyword = $request->get('search');
    	$perPage = 5;
    	$condition = array();

    	if(!empty($keyword)){
    		//DB::enableQueryLog();
    		$feedbacks = Feedback::where('feedback_query','Like',"%$keyword%")
    		->orderBy('id','DESC')->paginate($perPage);
    		//dd(DB::getQueryLog());

    	}else{
	        //$feedbacks = Feedback::all();
	        $feedbacks = Feedback::orderBy('id','DESC')->paginate($perPage);

    	}
    	return view('feedbacks.index',['feedbacks'=> $feedbacks])
	        	->with('i',($request->input('page',1)-1)*5);
    }
    
    public function create()
    {
        return view('feedbacks.create');
    }

    public function store(Request $request)
    {
    	//dd("hiii");
        $this->validate($request, [
        	'feedback_query' => 'required|min:3',
        	]);

        $curr_datetime = Carbon::now();
        $current_datetime = $curr_datetime->toDateTimeString();
        $feedback_status = 1;
        $request->request->add(['feedback_date' => $current_datetime,'feedback_status'=>$feedback_status]);
        Feedback::create($request->all());
        //dd($request);

        return redirect()->route('feedbacks.index')->with('success','Feedback added successfully.');
    }

    public function show($id)
    {
        $feedbacks = Feedback::find($id);
        return view('feedbacks.view',compact('feedbacks'));
    }

    public function edit($id)
    {
       $feedback = Feedback::find($id);
       return view('feedbacks.edit',compact('feedback'));
    }

    
    public function update(Request $request, $id)
    {
        $this->validate($request,[
        	'feedback_query'=>'required|min:3'
        	]);
        Feedback::find($id)->update($request->all());
        return redirect()->route('feedbacks.index')->
        with('success','Feedback updated successfully.');
    }

    
    public function destroy($id)
    {
        //
    }
}
