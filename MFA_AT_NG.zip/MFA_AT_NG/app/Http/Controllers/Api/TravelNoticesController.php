<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\TravelNotice;
use App\Traits\AuthorizesApiRequests;

class TravelNoticesController extends Controller
{
    use AuthorizesApiRequests;
    /*
     * function name : getEmgContact Web Service
     * Web Service for member emergency contact information
     * @author :  Rashmi
     * @access : public
     * @param : 
     * @return : JSON Response with HTTP Header
     */

    /**
     * @api {get} localhost:8000/api/emergency-contacts/get-econtacts  Profile
     * @apiName Profile
     * @apiGroup Member
     * @apiDescription
     * This api for member profile information
     *
     * @apiVersion 1.0.0
     * @apiHeader {String} Apikey  User access token { header }
     * @apiHeader {String} username  Api access username { header }
     * @apiHeader {String} password  Api access password { header }
     * @apiHeader {String} authtoken  Api access authtoken { header }
     * 
     * @apiSampleRequest localhost:8000/api/emergency-contacts/get-Econtacts
     *
     * @apiSuccess {Boolean} status true
     * @apiSuccess {Integer} status_code Status code, 200 for success
     * @apiSuccess {Object} result Data object
     * @apiSuccess {String} message message to user
     *
     * @apiSuccessExample Success-Response:
     *      HTTP/1.1 200 Ok.
     *        {
     *           "status": true,
     *           "status_code": 200,
     *           "message": "Login successfully.",
     *           "result": {
     *                       "id": 23,
     *                       "user_id": "2",
     *                       "name_of_contact": "Deepak Chourasiya",
     *                       "relationship": "Family",
     *                       "home_or_office_no": "5623895623",
     *                       "mobile_no": "8954125623",
     *                       "address": "xyz plaza, link road, mumbai",
     *                       "auth_token": "D95zT6lEzTxTlQgC2tJKTBUtLphGbE01rVDYDGSEjqa4DQs9DbwuRsVyAMVFUlpn", 
     *         }
     *		}
     *
     * @apiError WrongMethod request method must be GET
     * @apiErrorExample Error-Response: Wrong method
     *     HTTP/1.1 403 Forbidden.
     *      {
     *         "status": false,
     *         "result": {},
     *         "message": "Wrong request method, must be GET"
     *      }
     */
    public function getTravelNotices(){



    }
}
