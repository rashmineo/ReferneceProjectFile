<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-6 col-md-offset-3">
		
		<h3><?php echo e($userall->count()); ?> Out of <?php echo e($userall->total()); ?> Total Users</h3>
		<span><?php echo e($userall->currentPage()); ?> : currentPage</span>
		<span><?php echo e($userall->firstItem()); ?> : firstItem</span>
		<span><?php echo e($userall->hasMorePages()); ?> : hasMorePages</span>
		<span><?php echo e($userall->lastItem()); ?> : lastItem</span>
		<span><?php echo e($userall->nextPageUrl()); ?> : nextPageUrl</span>
		<span><?php echo e($userall->previousPageUrl()); ?> : previousPageUrl</span>
		<span><?php echo e($userall->perPage()); ?> : perPage</span>
		<ul class="list-group">
			<?php $__currentLoopData = $userall; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allusers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li class="list-group-item" style="margin-top: 20px">
			<span>
				<?php echo e($allusers->name); ?>

			</span>
			<span class="pull-right clearfix"> Joined
				<?php echo e($allusers->created_at->diffForHumans()); ?>

				<button class="btn btn-xs btn-primary">Follow</button>
			</span>

			</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php echo e($userall->links()); ?>

		</ul>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo $user['first_name']; ?><?php echo $user['last_name']; ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>