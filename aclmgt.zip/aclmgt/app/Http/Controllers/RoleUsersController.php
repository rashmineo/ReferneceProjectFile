<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\RoleUser;
use App\Models\User;
use App\Models\Role;

class RoleUsersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $roles=RoleUser::all();

        return view('role_user.index',compact('roles'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $roles=Role::pluck('name','id')->toArray();
        $users=User::pluck('name','id')->toArray();
        return view('role_user.create',compact('roles','users'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //dd($request->input('user_id'));
       $this->validate($request,
            [
                'role_id'=>'bail|required|numeric',
                'user_id'=>'bail|required|numeric',

            ]);
        //$isRolePresent=RoleUser::where('user_id',$request->input('user_id'))->first();

        $user = User::where('id',$request->input('user_id'))->first();
        // or by id
        $user->assignRole($request->input('role_id'));

        /*RoleUser::create([
                'role_id'=>$request->input('role_id'),
                'user_id'=>$request->input('user_id')
            ]);*/

        return redirect()->route('user-roles.index')->with('success','User Role added successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
       $userrole=RoleUser::find($id); 
       return view('role_user.view',compact('userrole'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $userrole = RoleUser::find($id);
        $roles = Role::pluck('name','id')->toArray();
        $users = User::pluck('name','id')->toArray();
        //dd($cities);
        return view('role_user.edit',compact('userrole','roles','users'));
    }

    public function update(Request $request, $id)
    {
        $this->validate($request,
            [
                'role_id'=>'bail|required|numeric',
                'user_id'=>'bail|required|numeric',

            ]);
       RoleUser::find($id)->update($request->all());
       return redirect()->route('user-roles.index')->with('success','User Role updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
