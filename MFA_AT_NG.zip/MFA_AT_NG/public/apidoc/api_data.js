define({ "api": [
  {
    "type": "post",
    "url": "http://localhost:8000/api/emergency-contacts/add",
    "title": "Add Contact",
    "name": "Add",
    "group": "Emergency_Contact",
    "description": "<p>This api is to add or edit emegency contact</p>",
    "version": "1.0.0",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Apikey",
            "description": "<p>User access token { header }</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "username",
            "description": "<p>Api access username { header }</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "password",
            "description": "<p>Api access password { header }</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "authtoken",
            "description": "<p>Api access authtoken { header }</p>"
          }
        ]
      }
    },
    "sampleRequest": [
      {
        "url": "localhost:8000/api/emergency-contacts/add"
      }
    ],
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name_of_contact",
            "description": "<p>contact name_of_contact is required</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "relationship",
            "description": "<p>contact relationship is required</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "home_or_office_no",
            "description": "<p>contact home_or_office_no is required</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "mobile_no",
            "description": "<p>contact mobile_no is required</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "address",
            "description": "<p>member address is required</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "status",
            "description": "<p>true</p>"
          },
          {
            "group": "Success 200",
            "type": "Integer",
            "optional": false,
            "field": "status_code",
            "description": "<p>Status code, 200 for success</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "result",
            "description": "<p>Data object</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>message to user</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 Ok.\n  {\n     \"status\": true,\n     \"status_code\": 200,\n     \"message\": \"Added successfully.\",\n     \"result\": {\n                 \"id\": 23,\n                 \"user_id\": \"2\",\n                 \"name_of_contact\": \"Deepak Chourasiya\",\n                 \"relationship\": \"Family member\",\n                 \"home_or_office_no\": \"5623895623\",\n                 \"mobile_no\": \"8954125623\",\n                 \"address\": \"xyz plaza, link road, mumbai\",\n                 \"auth_token\": \"D95zT6lEzTxTlQgC2tJKTBUtLphGbE01rVDYDGSEjqa4DQs9DbwuRsVyAMVFUlpn\",                      \n         }\n  }",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "WrongMethod",
            "description": "<p>request method must be POST</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response: Wrong method",
          "content": "HTTP/1.1 403 Forbidden.\n {\n    \"status\": false,\n    \"result\": {},\n    \"message\": \"Wrong request method, must be POST\"\n }",
          "type": "json"
        }
      ]
    },
    "filename": "app/Http/Controllers/Api/EmergencyContactsController.php",
    "groupTitle": "Emergency_Contact"
  },
  {
    "type": "get",
    "url": "http://localhost:8000/api/emergency-contacts/get-econtacts",
    "title": "Get Contact",
    "name": "Get_Emergency_Contact",
    "group": "Emergency_Contact",
    "description": "<p>This api for member profile information</p>",
    "version": "1.0.0",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Apikey",
            "description": "<p>User access token { header }</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "username",
            "description": "<p>Api access username { header }</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "password",
            "description": "<p>Api access password { header }</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "authtoken",
            "description": "<p>Api access authtoken { header }</p>"
          }
        ]
      }
    },
    "sampleRequest": [
      {
        "url": "http://localhost:8000/api/emergency-contacts/get-Econtacts"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "status",
            "description": "<p>true</p>"
          },
          {
            "group": "Success 200",
            "type": "Integer",
            "optional": false,
            "field": "status_code",
            "description": "<p>Status code, 200 for success</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "result",
            "description": "<p>Data object</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>message to user</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "     HTTP/1.1 200 Ok.\n       {\n          \"status\": true,\n          \"status_code\": 200,\n          \"message\": \"Login successfully.\",\n          \"result\": {\n                      \"id\": 23,\n                      \"user_id\": \"2\",\n                      \"name_of_contact\": \"Deepak Chourasiya\",\n                      \"relationship\": \"Family\",\n                      \"home_or_office_no\": \"5623895623\",\n                      \"mobile_no\": \"8954125623\",\n                      \"address\": \"xyz plaza, link road, mumbai\",\n                      \"auth_token\": \"D95zT6lEzTxTlQgC2tJKTBUtLphGbE01rVDYDGSEjqa4DQs9DbwuRsVyAMVFUlpn\", \n        }\n\t\t}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "WrongMethod",
            "description": "<p>request method must be GET</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response: Wrong method",
          "content": "HTTP/1.1 403 Forbidden.\n {\n    \"status\": false,\n    \"result\": {},\n    \"message\": \"Wrong request method, must be GET\"\n }",
          "type": "json"
        }
      ]
    },
    "filename": "app/Http/Controllers/Api/EmergencyContactsController.php",
    "groupTitle": "Emergency_Contact"
  },
  {
    "type": "post",
    "url": "http://mfa-at-ng.com/api/members/edit-profile",
    "title": "Edit Profile",
    "name": "Edit_Profile",
    "group": "Member",
    "description": "<p>This api for member edit personal profile information</p>",
    "version": "1.0.0",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Apikey",
            "description": "<p>User access token { header }</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "username",
            "description": "<p>Api access username { header }</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "password",
            "description": "<p>Api access password { header }</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "authtoken",
            "description": "<p>Api access authtoken { header }</p>"
          }
        ]
      }
    },
    "sampleRequest": [
      {
        "url": "http://mfa-at-ng.com/api/members/edit-profile"
      }
    ],
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "title",
            "description": "<p>member title is required , title in [MR, MISS Or MRS]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "first_name",
            "description": "<p>member first_name is required</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "last_name",
            "description": "<p>member last_name is required</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "gender",
            "description": "<p>member gender is required value enum('Male', 'Female')</p>"
          },
          {
            "group": "Parameter",
            "type": "Date",
            "optional": false,
            "field": "dob",
            "description": "<p>member dob is required of format YYYY-MM-DD</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "address",
            "description": "<p>member address is required</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "country_id",
            "description": "<p>member country_id is required</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "state_id",
            "description": "<p>member state_id is required</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "city_id",
            "description": "<p>member city_id is required</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>member email is required</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "phone_no",
            "description": "<p>member phone_no is required</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "nationality",
            "description": "<p>member nationality is required</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "status",
            "description": "<p>true</p>"
          },
          {
            "group": "Success 200",
            "type": "Integer",
            "optional": false,
            "field": "status_code",
            "description": "<p>Status code, 200 for success</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "result",
            "description": "<p>Data object</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>message to user</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 Ok.\n  {\n     \"status\": true,\n     \"status_code\": 200,\n     \"message\": \"Member profile updated successfully.\",\n     \"result\": {\n                 \"id\": 10,\n                 \"title\": \"MR\",\n                 \"name\": \"RatanEdit Ganure\",\n                 \"first_name\": \"RatanEdit\",\n                 \"last_name\": \"Ganure\",\n                 \"gender\": \"Male\",\n                 \"dob\": \"1992-10-05\",\n                 \"address\": \"Dadar\",\n                 \"country_id\": 101,\n                 \"state_id\": 22,\n                 \"city_id\": 2707,\n                 \"email\": \"ratan@gmail.com\",\n                 \"phone_no\": \"9546454813\",\n                 \"nationality\": \"Indian\",\n                 \"auth_token\": \"D95zT6lEzTxTlQgC2tJKTBUtLphGbE01rVDYDGSEjqa4DQs9DbwuRsVyAMVFUlpn\",\n                 \"country\": {\n                   \"id\": 101,\n                   \"sortname\": \"IN\",\n                   \"name\": \"India\",\n                   \"phonecode\": 91\n                 },\n                 \"state\": {\n                   \"id\": 22,\n                   \"name\": \"Maharashtra\",\n                   \"country_id\": 101\n                 },\n                 \"city\": {\n                   \"id\": 2707,\n                   \"name\": \"Mumbai\",\n                   \"state_id\": 22\n                 }\n         }\n  }",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "WrongMethod",
            "description": "<p>request method must be POST</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response: Wrong method",
          "content": "HTTP/1.1 403 Forbidden.\n {\n    \"status\": false,\n    \"result\": {},\n    \"message\": \"Wrong request method, must be POST\"\n }",
          "type": "json"
        }
      ]
    },
    "filename": "app/Http/Controllers/Api/MembersController.php",
    "groupTitle": "Member"
  },
  {
    "type": "post",
    "url": "http://mfa-at-ng.com/api/members/login",
    "title": "Login",
    "name": "Login",
    "group": "Member",
    "description": "<p>This api for member login</p>",
    "version": "1.0.0",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Apikey",
            "description": "<p>User access token { header }</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "username",
            "description": "<p>Api access username { header }</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "password",
            "description": "<p>Api access password { header }</p>"
          }
        ]
      }
    },
    "sampleRequest": [
      {
        "url": "http://mfa-at-ng.com/api/members/login"
      }
    ],
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>user email required</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "password",
            "description": "<p>user password required</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "status",
            "description": "<p>true</p>"
          },
          {
            "group": "Success 200",
            "type": "Integer",
            "optional": false,
            "field": "status_code",
            "description": "<p>Status code, 200 for success</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "result",
            "description": "<p>Data object</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>message to user</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 Ok.\n  {\n     \"status\": true,\n     \"status_code\": 200,\n     \"message\": \"Login successfully.\",\n     \"result\": {\n       \"id\": 4,\n       \"title\": \"MR\",\n       \"name\": \"Arjun Patil\",\n       \"first_name\": \"Arjun\",\n       \"last_name\": \"Patil\",\n       \"gender\": \"Male\",\n       \"dob\": \"1989-03-05\",\n       \"address\": \"Nana peth\",\n       \"country_id\": 101,\n       \"state_id\": 22,\n       \"city_id\": 276,\n       \"email\": \"arjunpatil@gmail.com\",\n       \"phone_no\": \"9546454649\",\n       \"nationality\": \"Indian\",\n       \"auth_token\": \"0XpS9fcg1Q1khpmBQb5cfItLnmBvxGUVlrzXB5zBrvnAJKG9NSi6xs6QTd2IeZrl\",\n       \"country\": {\n         \"id\": 101,\n         \"sortname\": \"IN\",\n         \"name\": \"India\",\n         \"phonecode\": 91\n       },\n       \"state\": {\n         \"id\": 22,\n         \"name\": \"Maharashtra\",\n         \"country_id\": 101\n       },\n       \"city\": {\n         \"id\": 276,\n         \"name\": \"Vadlapudi\",\n         \"state_id\": 2\n       }\n     }\n   }",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "WrongMethod",
            "description": "<p>request method must be POST</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response: Wrong method",
          "content": "HTTP/1.1 403 Forbidden.\n {\n    \"status\": false,\n    \"result\": {},\n    \"message\": \"Wrong request method, must be POST\"\n }",
          "type": "json"
        }
      ]
    },
    "filename": "app/Http/Controllers/Api/MembersController.php",
    "groupTitle": "Member"
  },
  {
    "type": "get",
    "url": "http://mfa-at-ng.com/api/members/get-profile",
    "title": "Profile",
    "name": "Profile",
    "group": "Member",
    "description": "<p>This api for member profile information</p>",
    "version": "1.0.0",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Apikey",
            "description": "<p>User access token { header }</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "username",
            "description": "<p>Api access username { header }</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "password",
            "description": "<p>Api access password { header }</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "authtoken",
            "description": "<p>Api access authtoken { header }</p>"
          }
        ]
      }
    },
    "sampleRequest": [
      {
        "url": "http://mfa-at-ng.com/api/members/get-profile"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "status",
            "description": "<p>true</p>"
          },
          {
            "group": "Success 200",
            "type": "Integer",
            "optional": false,
            "field": "status_code",
            "description": "<p>Status code, 200 for success</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "result",
            "description": "<p>Data object</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>message to user</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 Ok.\n  {\n     \"status\": true,\n     \"status_code\": 200,\n     \"message\": \"Login successfully.\",\n     \"result\": {\n                 \"id\": 10,\n                 \"title\": \"MR\",\n                 \"name\": \"Ratan Ganure\",\n                 \"first_name\": \"Ratan\",\n                 \"last_name\": \"Ganure\",\n                 \"gender\": \"Male\",\n                 \"dob\": \"1990-05-05\",\n                 \"address\": \"Dadar\",\n                 \"country_id\": 101,\n                 \"state_id\": 22,\n                 \"city_id\": 2707,\n                 \"email\": \"ratan@gmail.com\",\n                 \"phone_no\": \"9546454813\",\n                 \"nationality\": \"Indian\",\n                 \"auth_token\": \"o1aACNtuPCDIAypPvaqdjfTv3nns8Xc1HIRjOoGIxzqRuqtzJhMrHyOjdq5vsyES\",\n                 \"country\": {\n                   \"id\": 101,\n                   \"sortname\": \"IN\",\n                   \"name\": \"India\",\n                   \"phonecode\": 91\n                 },\n                 \"state\": {\n                   \"id\": 22,\n                   \"name\": \"Maharashtra\",\n                   \"country_id\": 101\n                 },\n                 \"city\": {\n                   \"id\": 2707,\n                   \"name\": \"Mumbai\",\n                   \"state_id\": 22\n                 }\n               }\n   }",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "WrongMethod",
            "description": "<p>request method must be GET</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response: Wrong method",
          "content": "HTTP/1.1 403 Forbidden.\n {\n    \"status\": false,\n    \"result\": {},\n    \"message\": \"Wrong request method, must be GET\"\n }",
          "type": "json"
        }
      ]
    },
    "filename": "app/Http/Controllers/Api/MembersController.php",
    "groupTitle": "Member"
  },
  {
    "type": "get",
    "url": "localhost:8000/api/emergency-contacts/get-econtacts",
    "title": "Profile",
    "name": "Profile",
    "group": "Member",
    "description": "<p>This api for member profile information</p>",
    "version": "1.0.0",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Apikey",
            "description": "<p>User access token { header }</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "username",
            "description": "<p>Api access username { header }</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "password",
            "description": "<p>Api access password { header }</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "authtoken",
            "description": "<p>Api access authtoken { header }</p>"
          }
        ]
      }
    },
    "sampleRequest": [
      {
        "url": "localhost:8000/api/emergency-contacts/get-Econtacts"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "status",
            "description": "<p>true</p>"
          },
          {
            "group": "Success 200",
            "type": "Integer",
            "optional": false,
            "field": "status_code",
            "description": "<p>Status code, 200 for success</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "result",
            "description": "<p>Data object</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>message to user</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "     HTTP/1.1 200 Ok.\n       {\n          \"status\": true,\n          \"status_code\": 200,\n          \"message\": \"Login successfully.\",\n          \"result\": {\n                      \"id\": 23,\n                      \"user_id\": \"2\",\n                      \"name_of_contact\": \"Deepak Chourasiya\",\n                      \"relationship\": \"Family\",\n                      \"home_or_office_no\": \"5623895623\",\n                      \"mobile_no\": \"8954125623\",\n                      \"address\": \"xyz plaza, link road, mumbai\",\n                      \"auth_token\": \"D95zT6lEzTxTlQgC2tJKTBUtLphGbE01rVDYDGSEjqa4DQs9DbwuRsVyAMVFUlpn\", \n        }\n\t\t}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "WrongMethod",
            "description": "<p>request method must be GET</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response: Wrong method",
          "content": "HTTP/1.1 403 Forbidden.\n {\n    \"status\": false,\n    \"result\": {},\n    \"message\": \"Wrong request method, must be GET\"\n }",
          "type": "json"
        }
      ]
    },
    "filename": "app/Http/Controllers/Api/TravelNoticesController.php",
    "groupTitle": "Member"
  },
  {
    "type": "post",
    "url": "http://mfa-at-ng.com/api/members/register",
    "title": "Register",
    "name": "Register",
    "group": "Member",
    "description": "<p>This api for member registration</p>",
    "version": "1.0.0",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Apikey",
            "description": "<p>User access token { header }</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "username",
            "description": "<p>Api access username { header }</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "password",
            "description": "<p>Api access password { header }</p>"
          }
        ]
      }
    },
    "sampleRequest": [
      {
        "url": "http://mfa-at-ng.com/api/members/register"
      }
    ],
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "title",
            "description": "<p>member title is required , title in [MR, MISS Or MRS]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "first_name",
            "description": "<p>member first_name is required</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "last_name",
            "description": "<p>member last_name is required</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "gender",
            "description": "<p>member gender is required value enum('Male', 'Female')</p>"
          },
          {
            "group": "Parameter",
            "type": "Date",
            "optional": false,
            "field": "dob",
            "description": "<p>member dob is required of format YYYY-MM-DD</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "address",
            "description": "<p>member address is required</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "country_id",
            "description": "<p>member country_id is required</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "state_id",
            "description": "<p>member state_id is required</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "city_id",
            "description": "<p>member city_id is required</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>member email is required</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "password",
            "description": "<p>member password is required</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "phone_no",
            "description": "<p>member phone_no is required</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "nationality",
            "description": "<p>member nationality is required</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "status",
            "description": "<p>true</p>"
          },
          {
            "group": "Success 200",
            "type": "Integer",
            "optional": false,
            "field": "status_code",
            "description": "<p>Status code, 200 for success</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "result",
            "description": "<p>Data object</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>message to user</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 Ok.\n  {\n     \"status\": true,\n     \"status_code\": 200,\n     \"message\": \"Registration successfully.\",\n     \"result\": {\n                 \"id\": 10,\n                 \"title\": \"MR\",\n                 \"name\": \"Ratan Ganure\",\n                 \"first_name\": \"Ratan\",\n                 \"last_name\": \"Ganure\",\n                 \"gender\": \"Male\",\n                 \"dob\": \"1990-05-05\",\n                 \"address\": \"Dadar\",\n                 \"country_id\": 101,\n                 \"state_id\": 22,\n                 \"city_id\": 2707,\n                 \"email\": \"ratan@gmail.com\",\n                 \"phone_no\": \"9546454813\",\n                 \"nationality\": \"Indian\",\n                 \"auth_token\": \"D95zT6lEzTxTlQgC2tJKTBUtLphGbE01rVDYDGSEjqa4DQs9DbwuRsVyAMVFUlpn\",\n                 \"country\": {\n                   \"id\": 101,\n                   \"sortname\": \"IN\",\n                   \"name\": \"India\",\n                   \"phonecode\": 91\n                 },\n                 \"state\": {\n                   \"id\": 22,\n                   \"name\": \"Maharashtra\",\n                   \"country_id\": 101\n                 },\n                 \"city\": {\n                   \"id\": 2707,\n                   \"name\": \"Mumbai\",\n                   \"state_id\": 22\n                 }\n         }\n  }",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "WrongMethod",
            "description": "<p>request method must be POST</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response: Wrong method",
          "content": "HTTP/1.1 403 Forbidden.\n {\n    \"status\": false,\n    \"result\": {},\n    \"message\": \"Wrong request method, must be POST\"\n }",
          "type": "json"
        }
      ]
    },
    "filename": "app/Http/Controllers/Api/MembersController.php",
    "groupTitle": "Member"
  }
] });
