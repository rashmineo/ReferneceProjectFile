<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Country;
use App\Models\City;
use App\Models\State;
use App\Models\PatientInformation;
use App\Models\PatientContact;
use App\Models\PatientHealthDetail;
use App\Models\PatientInsurance;
use Illuminate\Support\Facades\Input;
use DB;

class PatientInformationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $perPage=5;
        $patients=PatientInformation::orderBy('id','DESC')->paginate($perPage);
        //dd($patients->patientContact->email);
        
        //$patients=PatientInformation::find(29);
        //$conct = $patients->patientContact();
        //dd($patients->first()->patientContact->toArray());
        return view('patient_information.index',['patients'=>$patients])->with('i',($request->input('page','1')-1)*5);

    }

    
    public function create()
    {
        $countries = Country::pluck('name','id')->toArray(); //To fetch countries
        $states = [''=>'Select state']; //To fetch states
        $cities = [''=>'Select city']; //To fetch cities
        $gender = config('constants.GENDER_ENUM');
        $marital_status = config('constants.MARITAL_STATUS');
        $blood_group = config('constants.BLOOD_GROUP');
        $religion = config('constants.RELIGION');
        $id_type = config('constants.ID_TYPE');
        $allergies_type = config('constants.ALLERGIES_TYPE');
        //dd($states);
        return view('patient_information.create',compact('countries','states','cities','gender','marital_status','blood_group','religion','id_type','allergies_type'));
    }

    public function store(Request $request)
    {
        //dd($request->all());
        $this->validate($request,[
            'first_name'=>'bail|required|min:3',
            'middle_name'=>'bail|required|min:3',
            'last_name'=>'bail|required|min:3',
            'guardian_name'=>'bail|required|min:3',
            'dob'=>'bail|required|date',
            'birth_time'=>'bail',
            'gender'=>'bail|required|in:MALE,FEMALE',
            'marital_status'=>'bail|required|in:SINGLE,MARRIED,WIDOWED,DIVORCED,SEPRATED',
            'blood_group'=>'bail|required|in:A+VE,B+VE,AB+VE,O+VE,O-VE',
            'religion'=>'bail|in:HINDU,ISLAM,CHRISTIAN,SIKH,BUDDHISTH,JAIN,OTHER',
            'marital_status'=>'bail|required',
            'occupation'=>'bail|min:3',
            'organization_name'=>'bail|min:3',
            'profile_pic'=>'bail|mimes:jpeg,jpg,png|max:50000',
            'current_address'=>'bail|required|min:10',
            'current_city_id'=>'bail|required|numeric',
            'current_state_id'=>'bail|required|numeric',
            'current_country_id'=>'bail|required|numeric',
            'current_pincode'=>'bail|numeric',
            'permanent_address'=>'bail|min:10',
            'permanent_city_id'=>'bail|numeric',
            'permanent_country_id'=>'bail|numeric',
            'permanent_state_id'=>'bail|numeric',
            'permanent_pincode'=>'bail|numeric|min:5',
            'phone_number'=>'bail|required|regex:/[0-9]{10}/',
            'alt_phone_number'=>'bail|regex:/[0-9]{10}/',
            'email'=>'bail|required|min:3|email',
            'nationality'=>'bail|required|min:3',
            'id_type'=>'bail|required|in:AADHAR CARD,PAN CARD,ELECTION CARD,PASSPORT',
            'id_number'=>'bail|required|min:3',
            'garentor_name'=>'required|min:3',
            'garentor_gender'=>'bail|required|in:MALE,FEMALE',
            'garentor_relation'=>'required|min:3',
            'national_id'=>'bail|required|min:3',
            'policy_number'=>'bail|required',
            'policy_name'=>'bail|required|min:3',
            'agency'=>'bail|required|min:3',
            'allergies_type'=>'bail|required|in:FOOD ALLERGIES,SEASONAL ALLERGIES,PET ALLERGIES,DRUG ALLERGIES,OTHER',
            'allergens'=>'bail|required|min:3',
            'medical_history'=>'bail|required|min:20',
            'family_medical_history'=>'bail|required|min:20',
            'imp_note'=>'bail|required|min:3',
        ]);
		$filename="";
		//For upload Image start
		If($request->hasFile('profile_pic')){
            $file = $request->file('profile_pic');
            $destinationPath = public_path(). '/uploads/';
            $filename = $file->getClientOriginalName();
            $file->move($destinationPath, $filename);

            //echo  $filename;
            //echo '<img src="uploads/'. $filename . '"/>';
        }
        //Image upload end
        $convert_dob = date("Y-m-d", strtotime($request->input('dob')));
        //Transections for updating all the tables
     	// Start transaction!
		DB::beginTransaction();

		try {
		    // Validate, then create if valid
		    $PatientInformationId = PatientInformation::create([
				'mrn'=>'MYHCOL000002',
	            'first_name' =>$request->input('first_name'),
	            'middle_name' => $request->input('middle_name'),
	            'last_name'=>$request->input('last_name'),
	            'guardian_name'=>$request->input('guardian_name'),
	            'dob'=>$convert_dob,
	            'birth_time'=>$request->input('birth_time'),
	            'gender'=>$request->input('gender'),
	            'marital_status'=>$request->input('marital_status'),
	            'blood_group'=>$request->input('blood_group'),
	            'religion'=>$request->input('religion'),
	            'marital_status'=>$request->input('marital_status'),
	            'occupation'=>$request->input('occupation'),
	            'organization_name'=>$request->input('organization_name'),
	            'profile_pic' => $filename,
	        ])->id;



		    // Validate, then create if valid
		    $PatientContact = PatientContact::create([
				'patient_id'=>$PatientInformationId,
	            //'current_address' =>$request->input('current_address'),
	            'current_address' =>"sgadkgsakgfsgf",
	            'current_country_id' => $request->input('current_country_id'),
	            'current_city_id' => $request->input('current_city_id'),
	            'current_state_id'=>$request->input('current_state_id'),
	            'current_pincode'=>$request->input('current_pincode'),
	            'permanent_address'=>$request->input('permanent_address'),
	            'permanent_country_id' => $request->input('permanent_country_id'),
	            'permanent_state_id'=>$request->input('permanent_state_id'),
	            'permanent_city_id'=>$request->input('permanent_city_id'),
	            //'permanent_state_id'=>22,
	            //'permanent_city_id'=>2484,
	            'permanent_pincode' => $request->input('permanent_pincode'),
	            'phone_number'=>$request->input('phone_number'),
	            'alt_phone_number'=>$request->input('alt_phone_number'),
	            'email'=>$request->input('email'),
	            'nationality'=>$request->input('nationality'),
	            'id_type'=>$request->input('id_type'),
	            'id_number'=>$request->input('id_number'),
	        ]);

			//dd($PatientContact->toArray()); 

		    $PatientHealthDetail = PatientHealthDetail::create([
				'patient_id'=>$PatientInformationId,
	            'allergies_type' =>$request->input('allergies_type'),
	            'allergens' => $request->input('allergens'),
	            'medical_history'=>$request->input('medical_history'),
	            'family_medical_history'=>$request->input('family_medical_history'),
	            'imp_note'=>$request->input('imp_note'),
	        ]);
		    //dd($PatientHealthDetail->toArray());
		    // Validate, then create if valid
		    $PatientInsurance = PatientInsurance::create([
				'patient_id'=>$PatientInformationId,
	            'garentor_name' =>$request->input('garentor_name'),
	            'garentor_gender' => $request->input('garentor_gender'),
	            'garentor_relation'=>$request->input('garentor_relation'),
	            'national_id'=>$request->input('national_id'),
	            'policy_number'=>$request->input('policy_number'),
	            'policy_name'=>$request->input('policy_name'),
	            'agency'=>$request->input('agency'),
	        ]);
		    //dd($PatientInsurance->toArray());
		// If we reach here, then
		// data is valid and working.
		// Commit the queries!    
		DB::commit();

		
		} catch(ValidationException $e)
		{
		    // Rollback and then redirect
		    // back to form with errors
		    DB::rollback();
		    return Redirect::to('/create')
		        ->withErrors( $e->getErrors() )
		        ->withInput();
		} catch(\Exception $e)
		{
		    DB::rollback();
		    throw $e;
		}
        //dd($PatientHealthDetail);
        return redirect()->route('patient.index')->with('success','Registration done successfully.');
    }

    public function show($id)
    {
        //
    }

   
    public function edit($id)
    {
        $patient = PatientInformation::find($id);
        $conct = $patient->patientContact();
        //dd($conct->first()->toArray());
        dd($conct->current_country_id);
        $countries = Country::pluck('name','id')->toArray();
        $states = State::where('country_id',$conct->current_country_id)->pluck('name','id')->toArray();
        $cities = City::where('state_id',$conct->current_state_id)->pluck('name','id')->toArray();
        //dd($cities);
        return view('patient_information.edit',compact('patient','countries','states','cities'));
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        //
    }
}
