<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use App\Models\Country;
use App\Models\State;
use App\Models\City;
use Illuminate\Database\Eloquent\SoftDeletes;



class PatientInformation extends Model
{
    use Notifiable,SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'patient_information';
    protected $fillable = [
        'mrn','first_name', 'middle_name', 'last_name','guardian_name','dob','birth_time','gender','marital_status','blood_group','religion','occupation','organization_name','profile_pic',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */

    protected $dates = ['deleted_at'];


    public function country(){
        return $this->belongsTo('App\Models\Country');
    }
    public function state(){
        return $this->belongsTo('App\Models\State');
    }
    public function city(){
        return $this->belongsTo('App\Models\City');
    }
    public function patientContact(){
        return $this->hasOne('App\Models\PatientContact','patient_id');
    }
    public function patientInsurance(){
        return $this->hasOne('App\Models\PatientInsurance','patient_id');
    }
    public function patientHealthDetail(){
        return $this->hasOne('App\Models\PatientHealthDetail','patient_id');
    }
}
