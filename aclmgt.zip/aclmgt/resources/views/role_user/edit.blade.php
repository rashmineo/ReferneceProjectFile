@extends('layouts.app')

@section('title', 'Edit User Role')

@section('content_header')
    <h1>Edit User Role</h1>
@stop


@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Edit User Role #{{ $userrole->id }}</div>
                    <div class="panel-body">
                        <a href="{{ url('/user-roles') }}" title="Back"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <br />
                        <br />

                        {!! Form::model($userrole, [
                            'method' => 'PATCH',
                            'url' => ['/user-roles', $userrole->id],
                            'class' => 'form-horizontal',
                            'files' => true,
                        ]); !!}

                        @include ('role_user.form', ['submitButtonText' => 'Update'])

                        {!! Form::close() !!}

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
