<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Carbon\Carbon;

class ProfileController extends Controller
{
    public function profile($username){
    	//return $username;
    	$user = User::whereUsername($username)->first();
    	//return $user->email;
    	return view('user.profile',compact('user'));
    }
}
