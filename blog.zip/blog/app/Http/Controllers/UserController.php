<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;

class UserController extends Controller
{
    public function index(){
    	$users = [
    			"0" => [
    					'first_name'=> 'John',
    					'last_name'=> 'Doe'
    			],
    			"1" => [
    					'first_name'=> 'Tina',
    					'last_name' => 'Mica'
    			]
    	];
        //For factory method
        //$userall = User::all(); //Without pagination
        $userall = User::paginate(5); //For pagination
    	return view('admin.users.index',compact('users','userall'));
    }
    public function create(){
    	return view('admin.users.create');
    }
    public function save(Request $request){
    	//dd($request);
    	User::create($request->all());
    	return 'Successfully added.';
    	return $request->all();
    }
}
