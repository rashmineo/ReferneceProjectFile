<?php $__env->startSection('title','Manage Role'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Manage Role</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <strong>Manage Role</strong>
                    </div>
                    <div class="panel-body">
                        <a href="<?php echo e(url('/roles/')); ?>" class="btn btn-warning btn-xs" title="Add New Blog">
                            <i class="fa fa-arrow-left" aria-hidden="true"></i> Back
                        </a>
                        <br />
                        <br />
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <tbody>
                                    <tr>
                                        <th>ID</th><td><?php echo e($role->id); ?></td>
                                    </tr>
                                    <tr>
                                         <th>Name</th><td><?php echo e($role->name); ?></td>
                                    </tr> 
                                    <tr>
                                         <th>Slug</th><td><?php echo e($role->slug); ?></td>
                                    </tr> 
                                    <tr>
                                         <th>Description</th><td><?php echo e($role->description); ?></td>
                                    </tr> 
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>