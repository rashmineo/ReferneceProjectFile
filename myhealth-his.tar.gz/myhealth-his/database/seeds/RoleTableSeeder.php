<?php

use Illuminate\Database\Seeder;
use App\Role;
class RoleTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()

    {

        $role = [

        	[

        		'name' => 'admin',

        		'display_name' => 'Administrator',

        		'description' => 'Administrator User Role'

        	],

        	[

        		'name' => 'doctor',

        		'display_name' => 'Doctor',

        		'description' => 'Doctor User Role'

        	],

        	[	'name' => 'patient',

        		'display_name' => 'Patient',

        		'description' => 'Patient User Role'

        	]

        ];


        foreach ($role as $key => $value) {

        	Role::create($value);

        }

    }
}
