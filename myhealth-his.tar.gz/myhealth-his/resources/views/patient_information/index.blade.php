@extends('adminlte::page')

@section('title','View Patients')
@section('content_header')
    <h1>Manage Patients</h1>
@stop
@section('content')

<div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <strong>Manage Patients</strong>
                    </div>
                    <div class="panel-body">
                        <a href="{{ url('/patient/create') }}" class="btn btn-success btn-sm" title="Add New Blog">
                            <i class="fa fa-plus" aria-hidden="true"></i> Add New Patient
                        </a>

                        {!! Form::open(['method' => 'GET', 'url' => '/patient', 'class' => 'navbar-form navbar-right', 'role' => 'search'])  !!}
                        <div class="input-group">
                            <input type="text" class="form-control" name="search" placeholder="Search...">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                        </div>
                        {!! Form::close() !!}

                        <br/>
                        <br/>
        
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <thead>
                                    <tr>
                                        <th>Sr. No.</th>
                                        <th>MRN</th>
                                        <th>Photo</th>
                                        <th>Full Name</th>
                                        <th>Gender</th>
                                        <th>DOB</th>
                                        <th>Blood Group</th>
                                        <th>Email</th>
                                        <th>Phone No.</th>
                                        <th>Country</th>
                                        <th>State</th>
                                        <th>City</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $i=1; ?>
                                @foreach($patients as $patient)
                                    <tr>
                                        <td>{{ $i }}</td>
                                        <td>{{ $patient->mrn }}</td>
                                        <td>
                                            @if(isset($patient->profile_pic))
                                            <img src="{{ asset('uploads/' . $patient->profile_pic) }}" />
                                            @else
                                            {{ 'No image found' }}
                                            @endif
                                        </td>
                                        <td>{{ ucfirst($patient->first_name)." ". ucfirst($patient->last_name) }}</td>
                                        <td>{{ $patient->gender }}</td>
                                        <td>{{ $patient->dob }}</td>
                                        <td>{{ $patient->blood_group }}</td>
                                        <td> {{ $patient->patientContact->email }} </td>
                                        <td> {{ $patient->patientContact->phone_number }} </td>
                                        <td>{{ isset($patient->patientContact->country->name) ? $patient->patientContact->country->name : '-' }}</td>
                                        <td>{{ isset($patient->patientContact->state->name) ? $patient->patientContact->state->name : '-' }}</td>
                                        <td>{{ isset($patient->patientContact->city->name) ? $patient->patientContact->city->name : '-' }}</td>
                                        <td styel="width:280px">
                                            <a href="{{ url('/patients/' . $patient->id) }}" title="View User"><button class="btn btn-info btn-xs"><i class="fa fa-eye" aria-hidden="true"></i> View</button></a>
                                            <a href="{{ url('/patient/' . $patient->id . '/edit') }}" title="Edit User"><button class="btn btn-primary btn-xs"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</button></a>
                                            {!! Form::open([
                                                'method'=>'DELETE',
                                                'url' => ['/patient', $patient->id],
                                                'style' => 'display:inline'
                                            ]) !!}
                                            {!! Form::close() !!}
                                        </td>
                                    </tr>
                                <?php $i++; ?>
                                @endforeach
                                </tbody>
                            </table>
                            <div class="pagination-wrapper"> {!! $patients->appends(['search' => Request::get('search')])->render() !!} </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection