<?php $__env->startSection('title','View Users'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Manage Admin Users</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <strong>Manage Admin Users</strong>
                    </div>
                    <div class="panel-body">
                        <a href="<?php echo e(url('/adminusers/create')); ?>" class="btn btn-success btn-sm" title="Add New Blog">
                            <i class="fa fa-plus" aria-hidden="true"></i> Add New User
                        </a>

                        <?php echo Form::open(['method' => 'GET', 'url' => '/adminusers', 'class' => 'navbar-form navbar-right', 'role' => 'search']); ?>

                        <div class="input-group">
                            <input type="text" class="form-control" name="search" placeholder="Search...">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                        </div>
                        <?php echo Form::close(); ?>


                        <br/>
                        <br/>
        
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Title</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone No.</th>
                                        <th>Country</th>
                                        <th>State</th>
                                        <th>City</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $adminusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adminuser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                    
                                        <td><?php echo e($adminuser->id); ?></td>
                                        <td><?php echo e($adminuser->title); ?></td>
                                        <td><?php echo e(ucfirst($adminuser->first_name)." ". ucfirst($adminuser->last_name)); ?></td>
                                        <td><?php echo e($adminuser->email); ?></td>
                                        <td><?php echo e($adminuser->phone_no); ?></td>
                                        <td><?php echo e(isset($adminuser->country->name) ? $adminuser->country->name : '-'); ?></td>
                                        <td><?php echo e(isset($adminuser->state->name) ? $adminuser->state->name : '-'); ?></td>
                                        <td><?php echo e(isset($adminuser->city->name) ? $adminuser->city->name : '-'); ?></td>
                                        <td>
                                            <a href="<?php echo e(url('/adminusers/' . $adminuser->id)); ?>" title="View User"><button class="btn btn-info btn-xs"><i class="fa fa-eye" aria-hidden="true"></i> View</button></a>
                                            <a href="<?php echo e(url('/adminusers/' . $adminuser->id . '/edit')); ?>" title="Edit User"><button class="btn btn-primary btn-xs"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</button></a>
                                            <?php echo Form::open([
                                                'method'=>'DELETE',
                                                'url' => ['/adminusers', $adminuser->id],
                                                'style' => 'display:inline'
                                            ]); ?>

                                                <?php echo Form::button('<i class="fa fa-trash-o" aria-hidden="true"></i> Delete', array(
                                                        'type' => 'submit',
                                                        'class' => 'btn btn-danger btn-xs',
                                                        'title' => 'Delete User',
                                                        'onclick'=>'return confirm("Confirm delete?")'
                                                )); ?>

                                            <?php echo Form::close(); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div class="pagination-wrapper"> <?php echo $adminusers->appends(['search' => Request::get('search')])->render(); ?> </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>