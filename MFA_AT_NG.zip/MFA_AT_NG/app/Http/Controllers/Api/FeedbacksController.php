<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\Feedback;


class FeedbacksController extends Controller
{
    /*
     * function name : getfeedback Web Service
     * Web Service for feedback information
     * @author :  Rashmi
     * @access : public
     * @param : 
     * @return : JSON Response with HTTP Header
     */

    /**
     * @api {get} http://localhost:8000/api/feedbacks/get-feedbacks  Get Feedback
     * @apiName Get Feedback 
     * @apiGroup Feedback 
     * @apiDescription
     * This api for Feedback information
     *
     * @apiVersion 1.0.0
     * @apiHeader {String} Apikey  User access token { header }
     * @apiHeader {String} username  Api access username { header }
     * @apiHeader {String} password  Api access password { header }
     * @apiHeader {String} authtoken  Api access authtoken { header }
     * 
     * 
     * @apiSampleRequest http://localhost:8000/api/feedback/get-feedbacks
     *
     * @apiSuccess {Boolean} status true
     * @apiSuccess {Integer} status_code Status code, 200 for success
     * @apiSuccess {Object} result Data object
     * @apiSuccess {String} message message to user
     *
     * @apiSuccessExample Success-Response:
     *      HTTP/1.1 200 Ok.
     *        {
     *           "status": true,
     *           "status_code": 200,
     *           "message": "Login successfully.",
     *           "result": {
     *                       "id": 23,
     *                       "feedback_query": "Dummy feedback",
     *                       "feedback_date": "2017-03-02",
     *                       "feedback_status": "1",
     *                       "auth_token": "D95zT6lEzTxTlQgC2tJKTBUtLphGbE01rVDYDGSEjqa4DQs9DbwuRsVyAMVFUlpn", 
     *         }
     *		}
     *
     * @apiError WrongMethod request method must be GET
     * @apiErrorExample Error-Response: Wrong method
     *     HTTP/1.1 403 Forbidden.
     *      {
     *         "status": false,
     *         "result": {},
     *         "message": "Wrong request method, must be GET"
     *      }
     */
    public function getFeedbacks(Request $request){
    	$success_flag = config('constants.success_flag');
        $invalid_data = config('constants.invalid_data');        
        $data_missing = config('constants.data_missing');    
        $forbidden_access = config('constants.forbidden_access');        
        $response_code = config('constants.success_flag');

        $feedbacks = Feedback::all();
        $data = array('status'=>true, 'status_code'=>$success_flag, 'message'=>"Feedback details exist.", 'result'=>$feedbacks);
        return Response($data,$response_code) ;
    }
}
