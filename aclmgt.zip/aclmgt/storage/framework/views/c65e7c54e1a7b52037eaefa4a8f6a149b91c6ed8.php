<?php $__env->startSection('title', 'Add User Role'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Add User Role</h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Add User Role</div>
                    <div class="panel-body">
                        <a href="<?php echo e(url('/user-roles')); ?>" title="Back"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <br />
                        <br />
                        
                        <?php echo Form::open(['url' => '/user-roles', 'class' => 'form-horizontal', 'files' => true]); ?>


                        <?php echo $__env->make('role_user.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        
                        <?php echo Form::close(); ?>


                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>