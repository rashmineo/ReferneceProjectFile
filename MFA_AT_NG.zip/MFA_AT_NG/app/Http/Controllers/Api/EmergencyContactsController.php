<?php

namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use Auth;
use App\EmergencyContact;
use App\Traits\AuthorizesApiRequests;

use Illuminate\Http\Request;

class EmergencyContactsController extends Controller
{
   use AuthorizesApiRequests;
    /*
     * function name : Emergency contact add Web Service
     * Web Service for member register
     * @author :  Rashmi Narvare
     * @access : public
     * @param : Request $request object
     * @return : JSON Response with HTTP Header
     */
    
    /**
     * @api {post} http://localhost:8000/api/emergency-contacts/add  Add Contact
     * @apiName Add
     * @apiGroup Emergency Contact
     * @apiDescription
     * This api is to add or edit emegency contact
     *
     * @apiVersion 1.0.0
     * @apiHeader {String} Apikey  User access token { header }
     * @apiHeader {String} username  Api access username { header }
     * @apiHeader {String} password  Api access password { header }
     * @apiHeader {String} authtoken  Api access authtoken { header }
     * 
     * @apiSampleRequest http://localhost:8000/api/emergency-contacts/add
     *
     * @apiParam {String} name_of_contact contact name_of_contact is required
     * @apiParam {String} relationship contact relationship is required
     * @apiParam {String} home_or_office_no contact home_or_office_no is required
     * @apiParam {Number} mobile_no contact mobile_no is required
     * @apiParam {String} address member address is required
     *
     * @apiSuccess {Boolean} status true
     * @apiSuccess {Integer} status_code Status code, 200 for success
     * @apiSuccess {Object} result Data object
     * @apiSuccess {String} message message to user
     *
     * @apiSuccessExample Success-Response:
     *      HTTP/1.1 200 Ok.
     *        {
     *           "status": true,
     *           "status_code": 200,
     *           "message": "Added successfully.",
     *           "result": {
     *                       "id": 23,
     *                       "user_id": "2",
     *                       "name_of_contact": "Deepak Chourasiya",
     *                       "relationship": "Family member",
     *                       "home_or_office_no": "5623895623",
     *                       "mobile_no": "8954125623",
     *                       "address": "xyz plaza, link road, mumbai",
     *                       "auth_token": "D95zT6lEzTxTlQgC2tJKTBUtLphGbE01rVDYDGSEjqa4DQs9DbwuRsVyAMVFUlpn",                      
     *               }
     *        }
     *
     *
     * @apiError WrongMethod request method must be POST
     * @apiErrorExample Error-Response: Wrong method
     *     HTTP/1.1 403 Forbidden.
     *      {
     *         "status": false,
     *         "result": {},
     *         "message": "Wrong request method, must be POST"
     *      }
     */

    public function add(Request $request){
    	    $success_flag = config('constants.success_flag');
	        $invalid_data = config('constants.invalid_data');        
	        $data_missing = config('constants.data_missing');        
	        $failure_flag = config('constants.failure_flag');        
	        $forbidden_access = config('constants.forbidden_access');        
	        $response_code = config('constants.success_flag');

	        $member = $this->authorizeApiUser($request->header('authtoken'));
	        $request->request->set('user_id',$member->id);

	        $validator = \Validator::make($request->all(),[
	        	'user_id' =>'bail|required|numeric',
	        	'name_of_contact'=>'bail|required|alpha|between:1,128',
	        	'relationship'=>'bail|required|in:FAMILY,FRIEND,OFFICE',
	        	'home_or_office_no'=>'bail|required|numeric|regex:/[0-9]{10}/',
	        	'mobile_no'=>'bail|required|numeric|regex:/[0-9]{10}/',
	        	'address'=>'bail|required|min:3|max:512'
	        	],
	        	[
                    'relationship.in'=>'The selected relationship is in FAMILY, FRIEND Or OFFICE list'
                ]);
	        //return response($member);
	        if(!$validator->fails()){
	        	$request_code = $success_flag;
	        	try{
	        		

	        		$new_contact = EmergencyContact::where('user_id',$member->id)->first();
	        		if($new_contact==null){
		        		$new_contact=EmergencyContact::create($request->all());
	        		}
		        	else{
		        		EmergencyContact::where('user_id',$member->id)->update($request->all());
		        	}
		        	//return response($new_contact->id);
	        		if($new_contact!=null){
	        			$newcontact=EmergencyContact::select(['id','user_id','name_of_contact','relationship','home_or_office_no','mobile_no','address'])->find($new_contact->id);

	        			$data=array('status'=>true,'status_code'=>$success_flag,'message'=>'Contact added successfully','result'=>$newcontact);

	        		}else{
	        			$response_code=$invalid_data;
	        			$data=array('status'=>true,'status_code'=>$invalid_data,'message'=>'Failed to add contact.');
	        		}
	        	}catch(Exception $e){
	        		$response_code=$failure_flag;
	        		$data=array('status'=>false,'status_code'=>$failure_flag,'result'=>[],'message'=>'Intenal Server error');
	        	}
	        }else{
	        	$response_code=$data_missing;
	        	$data=array('status'=>false,'status_code'=>$data_missing,'result'=>[],'message'=>$validator->messages());
	        }
	        return response($data,$response_code);
    }
    /*
     * function name : getEmgContact Web Service
     * Web Service for member emergency contact information
     * @author :  Rashmi
     * @access : public
     * @param : 
     * @return : JSON Response with HTTP Header
     */

    /**
     * @api {get} http://localhost:8000/api/emergency-contacts/get-econtacts  Get Contact
     * @apiName Get Emergency Contact
     * @apiGroup Emergency Contact
     * @apiDescription
     * This api for member profile information
     *
     * @apiVersion 1.0.0
     * @apiHeader {String} Apikey  User access token { header }
     * @apiHeader {String} username  Api access username { header }
     * @apiHeader {String} password  Api access password { header }
     * @apiHeader {String} authtoken  Api access authtoken { header }
     * 
     * 
     * @apiSampleRequest http://localhost:8000/api/emergency-contacts/get-Econtacts
     *
     * @apiSuccess {Boolean} status true
     * @apiSuccess {Integer} status_code Status code, 200 for success
     * @apiSuccess {Object} result Data object
     * @apiSuccess {String} message message to user
     *
     * @apiSuccessExample Success-Response:
     *      HTTP/1.1 200 Ok.
     *        {
     *           "status": true,
     *           "status_code": 200,
     *           "message": "Login successfully.",
     *           "result": {
     *                       "id": 23,
     *                       "user_id": "2",
     *                       "name_of_contact": "Deepak Chourasiya",
     *                       "relationship": "Family",
     *                       "home_or_office_no": "5623895623",
     *                       "mobile_no": "8954125623",
     *                       "address": "xyz plaza, link road, mumbai",
     *                       "auth_token": "D95zT6lEzTxTlQgC2tJKTBUtLphGbE01rVDYDGSEjqa4DQs9DbwuRsVyAMVFUlpn", 
     *         }
     *		}
     *
     * @apiError WrongMethod request method must be GET
     * @apiErrorExample Error-Response: Wrong method
     *     HTTP/1.1 403 Forbidden.
     *      {
     *         "status": false,
     *         "result": {},
     *         "message": "Wrong request method, must be GET"
     *      }
     */
    public function getEcontact(Request $request){
    	$success_flag = config('constants.success_flag');
        $invalid_data = config('constants.invalid_data');        
        $data_missing = config('constants.data_missing');    
        $forbidden_access = config('constants.forbidden_access');        
        $response_code = config('constants.success_flag');

        $member = $this->authorizeApiUser($request->header('authtoken'));
        //return response($econatcts);
        $econatcts=EmergencyContact::where('user_id',$member->id)->first();
        $data = array('status'=>true, 'status_code'=>$success_flag, 'message'=>"Emergency Contact details exist.", 'result'=>$econatcts);                
        
        return response($data,$response_code);
    }
   
}
