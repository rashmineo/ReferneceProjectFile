<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});*/

/*Auth::routes();

Route::get('/home', 'HomeController@index');

Auth::routes();

Route::get('/home', 'HomeController@index');

Route::auth();


Route::group(['middleware' => ['auth']], function() {


	Route::get('/home', 'HomeController@index');
	Route::resource('users','UserController');
	Route::get('roles',['as'=>'roles.index','uses'=>'RoleController@index','middleware' => ['permission:role-list|role-create|role-edit|role-delete']]);

	Route::get('roles/create',['as'=>'roles.create','uses'=>'RoleController@create','middleware' => ['permission:role-create']]);

	Route::post('roles/create',['as'=>'roles.store','uses'=>'RoleController@store','middleware' => ['permission:role-create']]);

	Route::get('roles/{id}',['as'=>'roles.show','uses'=>'RoleController@show']);

	Route::get('roles/{id}/edit',['as'=>'roles.edit','uses'=>'RoleController@edit','middleware' => ['permission:role-edit']]);

	Route::patch('roles/{id}',['as'=>'roles.update','uses'=>'RoleController@update','middleware' => ['permission:role-edit']]);

	Route::delete('roles/{id}',['as'=>'roles.destroy','uses'=>'RoleController@destroy','middleware' => ['permission:role-delete']]);

});*/

Route::get('/', function () {
    return view('welcome');
});

//Route::auth();
Auth::routes();

Route::group(['middleware' => 'auth'], function() {

	Route::get('/home', 'HomeController@index');

	Route::resource('users', 'UserController');
	Route::get('roles', 'RoleController@index')
		->name('roles.index')
		->middleware('role:admin'); //role:root

	Route::get('roles/create', 'RoleController@create')
		->name('roles.create');

	Route::post('roles/create', 'RoleController@store')
		->name('roles.store');
		
	Route::get('roles/{id}', 'RoleController@show')
		->name('roles.show');
	Route::get('roles/{id}/edit', 'RoleController@edit')
		->name('roles.edit');
		// ->middleware('permission:role-edit');
	Route::patch('roles/{id}', 'RoleController@update')
		->name('roles.update');
		// ->middleware('permission:role-edit');
	Route::delete('roles/{id}', 'RoleController@delete')
		->name('roles.delete')
		->middleware('permission:role-delete');

        
	Route::get('permissions', 'PermissionsController@index')
		->name('permissions.index')
		->middleware('role:admin'); //role:root

	Route::get('permissions/create', 'PermissionsController@create')
		->name('permissions.create');

	Route::post('permissions/create', 'PermissionsController@store')
		->name('roles.store');
		
	Route::get('permissions/{id}', 'PermissionsController@show')
		->name('permissions.show');
        
	Route::get('permissions/{id}/edit', 'PermissionsController@edit')
		->name('permissions.edit');
		// ->middleware('permission:role-edit');
	Route::patch('permissions/{id}', 'PermissionsController@update')
		->name('permissions.update');
		// ->middleware('permission:role-edit');
	Route::delete('permissions/{id}', 'PermissionsController@delete')
		->name('permissions.delete')
		->middleware('permission:role-delete');

        
        
});

Route::resource('patient','PatientInformationController');
Route::get('get-countries','LocationsController@getCountries');
Route::post('get-countries','LocationsController@getCountries');
Route::get('get-states','LocationsController@getStates');
Route::post('get-states','LocationsController@getStates');
Route::get('get-cities','LocationsController@getCities');
Route::post('get-cities','LocationsController@getCities'); 