<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Role;
use Illuminate\Support\Facades\Validator;

class RolesController extends Controller
{
   
    public function index(Request $request)
    {
        $roles=Role::all();
        return view('roles.index',compact('roles'));
    }

    public function create()
    {
        return view('roles.create');
    }

    
    public function store(Request $request)
    {
        $this->validate($request,
            [
                'name'=>'bail|required|min:3|unique:roles,name',
                'description'=>'bail|required|min:3|max:512',

            ]);
        $role = new Role();
        $roleAdmin = $role->create([
            'name' => $request->input('name'),
            'slug' => strtolower($request->input('name')),
            'description' => $request->input('description'),
        ]);
        return redirect()->route('roles.index')->with('success','Role added successfully.');
    }

    
    public function show($id)
    {
        $role=Role::find($id);
        return view('roles.view',compact('role'));
    }

    
    public function edit($id)
    {
        //
    }

    
    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        //
    }
}
