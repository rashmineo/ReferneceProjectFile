<div class="box box-default">
    <div class="box-header with-border">
      <h3 class="box-title">Patient Basic Information</h3>

      <div class="box-tools pull-right">
        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
        <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
      </div>
    </div>
    <!-- /.box-header -->
    <div class="box-body" style="display: block;">
      <div class="row">
        <div class="col-md-6"><!-- **************************** -->
            <!-- Start Patient Basic Information section -->
            <div class="form-group {{ $errors->has('new_born') ? 'has-error' : ''}}">
                {!! Form::label('new_born', 'New Born', ['class' => 'col-md-4 control-label']) !!}
                <div class="col-md-6">
                    {!! Form::checkbox('new_born', 'new_born', false, array('class' => 'name','id'=>'new_born')); !!}
                    {!! $errors->first('new_born', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('first_name') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('first_name', 'First Name <span class="text-success">*</span>', ['class' => 'col-md-4 control-label required'])) !!}
                <div class="col-md-6">
                    {!! Form::text('first_name', null, ['class' => 'form-control','id'=>'first_name']) !!}
                    {!! $errors->first('first_name', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('middle_name') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('middle_name', 'Middle Name <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                    {!! Form::text('middle_name', null, ['class' => 'form-control']) !!}
                    {!! $errors->first('middle_name', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('last_name') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('last_name', 'Last Name <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                    {!! Form::text('last_name', null, ['class' => 'form-control']) !!}
                    {!! $errors->first('last_name', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('guardian_name') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('guardian_name', 'Guardian Name <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                    {!! Form::text('guardian_name', null, ['class' => 'form-control']) !!}
                    {!! $errors->first('guardian_name', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('dob') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('dob', 'Date of Birth <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                    {!! Form::text('dob', null, ['class' => 'form-control','id'=>'dob']) !!}
                    {!! $errors->first('dob', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('birth_time') ? 'has-error' : ''}}">
                {!! Form::label('birth_time', 'Birth Time', ['class' => 'col-md-4 control-label']) !!}
                <div class="col-md-6">
                    {!! Form::text('birth_time', null, ['class' => 'form-control']) !!}
                    {!! $errors->first('birth_time', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('gender') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('gender', 'Gender <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">

                   {!! Form::select('gender', $gender, null, ['class' => 'form-control','id'=>"gender"]) !!}

                    {!! $errors->first('gender', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('marital_status') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('marital_status', 'Marital Status <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                    {!! Form::select('marital_status', $marital_status, null, ['class' => 'form-control','id'=>"gender"]) !!}
                    {!! $errors->first('marital_status', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('blood_group') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('blood_group', 'Blood Group <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                   {!! Form::select('blood_group', $blood_group, null, ['class' => 'form-control','id'=>"blood_group"]) !!}

                    {!! $errors->first('blood_group', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('religion') ? 'has-error' : ''}}">
                {!! Form::label('religion', 'Religion', ['class' => 'col-md-4 control-label']) !!}
                <div class="col-md-6">

                   {!! Form::select('religion', $religion, null, ['class' => 'form-control','id'=>"religion"]) !!}

                    {!! $errors->first('religion', '<p class="help-block">:message</p>') !!}
                </div>
            </div>

            <div class="form-group {{ $errors->has('occupation') ? 'has-error' : ''}}">
                {!! Form::label('occupation', 'Occupation', ['class' => 'col-md-4 control-label']) !!}
                <div class="col-md-6">
                    {!! Form::text('occupation', null, ['class' => 'form-control']) !!}
                    {!! $errors->first('occupation', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('organization_name') ? 'has-error' : ''}}">
                {!! Form::label('organization_name', 'Organization Name', ['class' => 'col-md-4 control-label']) !!}
                <div class="col-md-6">
                    {!! Form::text('organization_name', null, ['class' => 'form-control']) !!}
                    {!! $errors->first('organization_name', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('profile_pic') ? 'has-error' : ''}}">
                {!! Form::label('profile_pic', 'Profile Pic', ['class' => 'col-md-4 control-label']) !!}
                <div class="col-md-6">
                    {!! Form::file('profile_pic', null, ['class' => 'form-control']) !!}
                    {!! $errors->first('profile_pic', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <!-- End Patient Basic Information section -->

        </div><!-- **************************** -->
      </div>
    </div>
</div> 

<!-- Start Patient Contact Information section -->
<div class="box box-default">
    <div class="box-header with-border">
      <h3 class="box-title">Patient Contact Information</h3>

      <div class="box-tools pull-right">
        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
        <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
      </div>
    </div>
    <!-- /.box-header -->
    <div class="box-body" style="display: block;">
      <div class="row">
        <div class="col-md-6"><!-- **************************** -->
            <!-- Start Patient Basic Information section -->
            <div class="form-group {{ $errors->has('current_address') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('current_address', 'Current Address <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                    {!! Form::textarea('current_address', null, ['class' => 'form-control','rows' => 2, 'cols' => 40]) !!}
                    {!! $errors->first('current_address', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('current_country_id') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('current_country_id', 'Current Country <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                   {!! Form::select('current_country_id', $countries, null, ['class' => 'form-control countries','id'=>"current_country_id"]) !!}
                    {!! $errors->first('current_country_id', '<p class="help-block">:message</p>') !!}
                </div>
            </div>

            <div class="form-group {{ $errors->has('current_state_id') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('current_state_id', 'Current State <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                    {!! Form::select('current_state_id', array_merge(['' => 'Please Select'], $states), null, ['class' => 'form-control states','id'=>"current_state_id"]) !!}
                    {!! $errors->first('current_state_id', '<p class="help-block">:message</p>') !!}
                </div>
            </div>

            <div class="form-group {{ $errors->has('current_city_id') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('current_city_id', 'Current City <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                    {!! Form::select('current_city_id', array_merge(['' => 'Please Select'], $cities), null, ['class' => 'form-control cities','id'=>"current_city_id"]) !!}
                    {!! $errors->first('current_city_id', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
             <div class="form-group {{ $errors->has('current_pincode') ? 'has-error' : ''}}">
                {!! Form::label('current_pincode', 'Current Pincode', ['class' => 'col-md-4 control-label']) !!}
                <div class="col-md-6">
                    {!! Form::text('current_pincode', null, ['class' => 'form-control','id'=>'current_pincode']) !!}
                    {!! $errors->first('current_pincode', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('same_address') ? 'has-error' : ''}}">
                {!! Form::label('same_address', 'Same as current address', ['class' => 'col-md-4 control-label']) !!}
                <div class="col-md-6">
                    {!! Form::checkbox('same_address', 'same_address', false, array('class' => 'name','id'=>'same_address')); !!}
                    {!! $errors->first('same_address', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('permanent_address') ? 'has-error' : ''}}">
                {!! Form::label('permanent_address', 'Permanent Address', ['class' => 'col-md-4 control-label']) !!}
                <div class="col-md-6">
                    {!! Form::textarea('permanent_address', null, ['class' => 'form-control','rows' => 2, 'cols' => 40]) !!}
                    {!! $errors->first('permanent_address', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            
            <div class="form-group {{ $errors->has('permanent_country_id') ? 'has-error' : ''}}">
                {!! Form::label('permanent_country_id', 'Permanent Country', ['class' => 'col-md-4 control-label']) !!}
                <div class="col-md-6">
                   {!! Form::select('permanent_country_id', $countries, null, ['class' => 'form-control per-countries','id'=>"permanent_country_id"]) !!}
                    {!! $errors->first('permanent_country_id', '<p class="help-block">:message</p>') !!}
                </div>
            </div>

            <div class="form-group {{ $errors->has('permanent_state_id') ? 'has-error' : ''}}">
                {!! Form::label('permanent_state_id', 'Permanent State', ['class' => 'col-md-4 control-label']) !!}
                <div class="col-md-6">
                    {!! Form::select('permanent_state_id', array_merge(['' => 'Please Select'], $states), null, ['class' => 'form-control per-states','id'=>"permanent_state_id"]) !!}
                    {!! $errors->first('permanent_state_id', '<p class="help-block">:message</p>') !!}
                </div>
            </div>

            <div class="form-group {{ $errors->has('permanent_city_id') ? 'has-error' : ''}}">
                {!! Form::label('permanent_city_id', 'Permanent City', ['class' => 'col-md-4 control-label']) !!}
                <div class="col-md-6">
                    {!! Form::select('permanent_city_id', array_merge(['' => 'Please Select'], $cities), null, ['class' => 'form-control per-cities','id'=>"permanent_city_id"]) !!}
                    {!! $errors->first('permanent_city_id', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
           
            <div class="form-group {{ $errors->has('permanent_pincode') ? 'has-error' : ''}}">
                {!! Form::label('permanent_pincode', 'Permanent Pincode', ['class' => 'col-md-4 control-label']) !!}
                <div class="col-md-6">
                    {!! Form::text('permanent_pincode', null, ['class' => 'form-control','id'=>'permanent_pincode']) !!}
                    {!! $errors->first('permanent_pincode', '<p class="help-block">:message</p>') !!}
                </div>
            </div>

            <div class="form-group {{ $errors->has('phone_number') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('phone_number', 'Phone Number <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                    {!! Form::text('phone_number', null, ['class' => 'form-control']) !!}
                    {!! $errors->first('phone_number', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('alt_phone_number') ? 'has-error' : ''}}">
                {!! Form::label('alt_phone_number', 'Alt. Phone Number', ['class' => 'col-md-4 control-label']) !!}
                <div class="col-md-6">
                    {!! Form::text('alt_phone_number', null, ['class' => 'form-control']) !!}
                    {!! $errors->first('alt_phone_number', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('email') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('email', 'Email address <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                    {!! Form::email('email', null, ['class' => 'form-control']) !!}
                    {!! $errors->first('email', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('nationality') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('nationality', 'Nationality <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                    {!! Form::text('nationality', null, ['class' => 'form-control']) !!}
                    {!! $errors->first('nationality', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('id_type') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('id_type', 'ID Type <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                    {!! Form::select('id_type', $id_type, null, ['class' => 'form-control','id'=>"id_type"]) !!}
                    {!! $errors->first('id_type', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('id_number') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('id_number', 'ID Number <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                    {!! Form::text('id_number', null, ['class' => 'form-control','id'=>'id_number']) !!}
                    {!! $errors->first('id_number', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <!-- End Patient Basic Information section -->
        </div><!-- **************************** -->
      </div>
    </div>
</div> 
<!-- End Patient Contact Information -->
<!-- Start Patient Insuranace Info section -->
<div class="box box-default">
    <div class="box-header with-border">
      <h3 class="box-title">Patient Insurnace Information</h3>

      <div class="box-tools pull-right">
        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
        <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
      </div>
    </div>
    <!-- /.box-header -->
    <div class="box-body" style="display: block;">
      <div class="row">
        <div class="col-md-6"><!-- **************************** -->
            <div class="form-group {{ $errors->has('same_garentor') ? 'has-error' : ''}}">
                {!! Form::label('same_garentor', 'Myself', ['class' => 'col-md-4 control-label']) !!}
                <div class="col-md-6">
                    {!! Form::checkbox('same_garentor', 'same_garentor', false, array('class' => 'name','id'=>'same_garentor')); !!}
                    {!! $errors->first('same_garentor', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('garentor_name') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('garentor_name', 'Garentor Name <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                    {!! Form::text('garentor_name', null, ['class' => 'form-control']) !!}
                    {!! $errors->first('garentor_name', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
             <div class="form-group {{ $errors->has('garentor_gender') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('garentor_gender', 'Garentor Gender <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">

                   {!! Form::select('garentor_gender', $gender, null, ['class' => 'form-control','id'=>"garentor_gender"]) !!}

                    {!! $errors->first('garentor_gender', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('garentor_relation') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('garentor_relation', 'Garentor Relation <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                    {!! Form::text('garentor_relation', null, ['class' => 'form-control']) !!}
                    {!! $errors->first('garentor_relation', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('national_id') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('national_id', 'National ID <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                    {!! Form::text('national_id', null, ['class' => 'form-control']) !!}
                    {!! $errors->first('national_id', '<p class="help-block">:message</p>') !!}
                </div>
            </div>

            <div class="form-group {{ $errors->has('policy_number') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('policy_number', 'Policy Number <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                    {!! Form::text('policy_number', null, ['class' => 'form-control']) !!}
                    {!! $errors->first('policy_number', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('policy_name') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('policy_name', 'Policy Name <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                    {!! Form::text('policy_name', null, ['class' => 'form-control']) !!}
                    {!! $errors->first('policy_name', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('agency') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('agency', 'Agency <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                    {!! Form::text('agency', null, ['class' => 'form-control']) !!}
                    {!! $errors->first('agency', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
        </div><!-- **************************** -->
      </div>
    </div>
</div> 
<!-- End Patient Insuranace Info -->
<!-- Start Patient Health Info section -->
<div class="box box-default">
    <div class="box-header with-border">
      <h3 class="box-title">Patient Health Issue</h3>

      <div class="box-tools pull-right">
        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
        <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
      </div>
    </div>
    <!-- /.box-header -->
    <div class="box-body" style="display: block;">
      <div class="row">
        <div class="col-md-6"><!-- **************************** -->
             <div class="form-group {{ $errors->has('allergies_type') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('allergies_type', 'Allergies Type <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">

                   {!! Form::select('allergies_type', $allergies_type, null, ['class' => 'form-control','id'=>"allergies_type"]) !!}

                    {!! $errors->first('allergies_type', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('allergens') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('allergens', 'Allergens <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                    {!! Form::textarea('allergens', null, ['class' => 'form-control','rows' => 2, 'cols' => 40]) !!}
                    {!! $errors->first('allergens', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('medical_history') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('medical_history', 'Medical History <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                    {!! Form::textarea('medical_history', null, ['class' => 'form-control','rows' => 2, 'cols' => 40]) !!}
                    {!! $errors->first('medical_history', '<p class="help-block">:message</p>') !!}
                </div>
            </div>

            <div class="form-group {{ $errors->has('family_medical_history') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('family_medical_history', 'Family Medical History <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                    {!! Form::textarea('family_medical_history', null, ['class' => 'form-control','rows' => 2, 'cols' => 40]) !!}
                    {!! $errors->first('family_medical_history', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('imp_note') ? 'has-error' : ''}}">
                {!! Html::decode(Form::label('imp_note', 'Imporatant Note <span class="text-success">*</span>', ['class' => 'col-md-4 control-label'])) !!}
                <div class="col-md-6">
                    {!! Form::textarea('imp_note', null, ['class' => 'form-control','rows' => 2, 'cols' => 40]) !!}
                    {!! $errors->first('imp_note', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
        </div><!-- **************************** -->
      </div>
    </div>
</div> 
<!-- End Patient Health Info section -->
<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        {!! Form::submit(isset($submitButtonText) ? $submitButtonText : 'Register', ['class' => 'btn btn-primary']) !!}
    </div>
</div>
<script type="text/javascript">
    //alert('{{url("api/get-states")}}');
    function ajaxCall() {
        this.send = function(data, url, method, success, type) {
          type = type||'json';
          var successRes = function(data) {
              success(data);
          };

          var errorRes = function(e) {
              console.log(e);
              alert("Error found \nError Code: "+e.status+" \nError Message: "+e.statusText);
          };
            $.ajax({
                url: url,
                type: method,
                data: data,
                success: successRes,
                error: errorRes,
                dataType: type,
                timeout: 60000
            });

          }

        }

function locationInfo() {
    var call = new ajaxCall();
    this.getCities = function(id) {
        $(".cities option:gt(0)").remove();
        var url = '{{url("get-cities")}}';
        var method = "post";
        var csrfToken = Laravel.csrfToken;
        var data = {'state_id':id,'_token': csrfToken};
        $('.cities').find("option:eq(0)").html("Please wait..");
        call.send(data, url, method, function(data) {
            $('.cities').find("option:eq(0)").html("Select City");
            if(data.tp == 1){
                $.each(data['result'], function(key, val) {
                    var option = $('<option />');
                    option.attr('value', key).text(val);
                    $('.cities').append(option);
                });
                $(".cities").prop("disabled",false);
            }
            else{
                 //alert(data.msg);
            }
        });
    };
    this.getPerAddCities = function(id) {
        $(".per-cities option:gt(0)").remove();
        var url = '{{url("get-cities")}}';
        var method = "post";
        var csrfToken = Laravel.csrfToken;
        var data = {'state_id':id,'_token': csrfToken};
        $('.per-cities').find("option:eq(0)").html("Please wait..");
        call.send(data, url, method, function(data) {
            $('.per-cities').find("option:eq(0)").html("Select City");
            if(data.tp == 1){
                $.each(data['result'], function(key, val) {
                    var option = $('<option />');
                    option.attr('value', key).text(val);
                    $('.per-cities').append(option);
                });
                $(".per-cities").prop("disabled",false);
            }
            else{
                 //alert(data.msg);
            }
        });
    };

    this.getStates = function(id) {
        $(".states option:gt(0)").remove(); 
        $(".cities option:gt(0)").remove(); 
        var url = '{{url("get-states")}}';
        var method = "post";
        var csrfToken = Laravel.csrfToken;
        var data = {'country_id':id,'_token': csrfToken};
        $('.states').find("option:eq(0)").html("Please wait..");
        call.send(data, url, method, function(data) {
            $('.states').find("option:eq(0)").html("Select State");
            if(data.tp == 1){
                $.each(data['result'], function(key, val) {
                    var option = $('<option />');
                    option.attr('value', key).text(val);
                    $('.states').append(option);
                });
                $(".states").prop("disabled",false);
            }
            else{
                //alert(data.msg);
            }
        }); 
    };
    this.getPerAddStates = function(id) {
        $(".per-states option:gt(0)").remove(); 
        $(".per-cities option:gt(0)").remove(); 
        var url = '{{url("get-states")}}';
        var method = "post";
        var csrfToken = Laravel.csrfToken;
        var data = {'country_id':id,'_token': csrfToken};
        $('.per-states').find("option:eq(0)").html("Please wait..");
        call.send(data, url, method, function(data) {
            $('.per-states').find("option:eq(0)").html("Select State");
            if(data.tp == 1){
                $.each(data['result'], function(key, val) {
                    var option = $('<option />');
                    option.attr('value', key).text(val);
                    $('.per-states').append(option);
                });
                $(".per-states").prop("disabled",false);
            }
            else{
                //alert(data.msg);
            }
        }); 
    };

    this.getCountries = function() {
        var url = '{{url("get-countries")}}';
        var method = "post";
        var csrfToken = Laravel.csrfToken;
        var data = {'_token': csrfToken};
        $('.countries').find("option:eq(0)").html("Please wait..");
        call.send(data, url, method, function(data) {
            $('.countries').find("option:eq(0)").html("Select Country");
            console.log(data);
            if(data.tp == 1){
                $.each(data['result'], function(key, val) {
                    var option = $('<option />');
                    option.attr('value', key).text(val);
                    $('.countries').append(option);
                });
                $(".countries").prop("disabled",false);
            }
            else{
                //alert(data.msg);
            }
        }); 
    };
    this.getPerAddCountries = function() {
        var url = '{{url("get-countries")}}';
        var method = "post";
        var csrfToken = Laravel.csrfToken;
        var data = {'_token': csrfToken};
        $('.per-countries').find("option:eq(0)").html("Please wait..");
        call.send(data, url, method, function(data) {
            $('.per-countries').find("option:eq(0)").html("Select Country");
            console.log(data);
            if(data.tp == 1){
                $.each(data['result'], function(key, val) {
                    var option = $('<option />');
                    option.attr('value', key).text(val);
                    $('.per-countries').append(option);
                });
                $(".per-countries").prop("disabled",false);
            }
            else{
                //alert(data.msg);
            }
        }); 
    };

}

$(function() {
var loc = new locationInfo();
loc.getCountries();
//for permanet address
loc.getPerAddCountries();
$(".countries").on("change", function(ev) {
    var countryId = $(this).val();
    if(countryId != ''){
    loc.getStates(countryId);
    }
    else{
        $(".states option:gt(0)").remove();
    }
});
$(".states").on("change", function(ev) {
    var stateId = $(this).val();
    if(stateId != ''){
    loc.getCities(stateId);
    }
    else{
        $(".cities option:gt(0)").remove();
    }
});
$(".per-countries").on("change", function(ev) {
    var countryId = $(this).val();
    if(countryId != ''){
    loc.getPerAddStates(countryId);
    }
    else{
        $(".per-states option:gt(0)").remove();
    }
});
$(".per-states").on("change", function(ev) {
    var stateId = $(this).val();
    if(stateId != ''){
    loc.getPerAddCities(stateId);
    }
    else{
        $(".per-states option:gt(0)").remove();
    }
});
//For same address checkbox
$("#same_address").on("change", function(ev) {
    var same_addressId = $(this).val();
    //alert(same_addressId);
    if (!$(this).is(':checked')) {
        //return confirm("Are you sure?");
        $(".per-countries option").remove();
        $(".per-states option").remove();
        $(".per-cities option").remove();
        $("#permanent_address").val("");
        $("#permanent_pincode").val("");
        //Remove disabled
        $("#permanent_address").attr('readonly',false);
        $('#permanent_country_id').attr('readonly',false);
        $('#permanent_state_id').attr('readonly',false);
        $('#permanent_city_id').attr('readonly',false);
        $("#permanent_pincode").attr('readonly',false);
        loc.getPerAddCountries();
    }else{
        if(same_addressId != ''){
            current_address=$("#current_address").val();
            current_country_id=$("#current_country_id option:selected").val();
            current_state_id=$("#current_state_id option:selected").val();
            current_city_id=$("#current_city_id option:selected").val();
            current_state_text=$("#current_state_id option:selected").text();
            current_city_text=$("#current_city_id option:selected").text();
            current_pincode=$("#current_pincode").val();
            if(current_address!=""&&current_country_id!=""&&current_state_id!=""&&current_city_id!=""){
                $("#permanent_address").val(current_address);
                $('#permanent_country_id option[value='+current_country_id+']').attr('selected','selected');

                $("#permanent_state_id option:eq(0)").remove();
                $('#permanent_state_id').append('<option value="'+current_state_id+'">'+current_state_text+'</option>');
                $('#permanent_state_id option[value='+current_state_id+']').attr('selected','selected');

                $("#permanent_city_id option:eq(0)").remove();
                $('#permanent_city_id').append('<option value="'+current_city_id+'">'+current_city_text+'</option>');
                
                $('#permanent_city_id option[value='+current_city_id+']').attr('selected','selected');
                $("#permanent_pincode").val(current_pincode);

                //Disable all the fields
                $("#permanent_address").attr('readonly',true);
                $('#permanent_country_id').attr('readonly',true);
                $('#permanent_state_id').attr('readonly',true);
                $('#permanent_city_id').attr('readonly',true);
                $("#permanent_pincode").attr('readonly',true);

            }else{
                $(this).attr('checked',false);
                alert("Please fill all current address details!");
            }
        }
    }
    
});
//For granetor 
$("#same_garentor").on("change", function(ev) {
    var same_garentorId = $(this).val();
    //alert(same_addressId);
    if (!$(this).is(':checked')) {
        //return confirm("Are you sure?");
        $("#garentor_gender option:eq(0)").attr('selected','selected');
        //Remove disabled
        $("#garentor_name").attr('readonly',false);
        $('#garentor_gender').attr('readonly',false);
        $('#garentor_relation').attr('readonly',false);
        $('#national_id').attr('readonly',false);
    }else{
        if(same_garentorId != ''){
            first_name=$("#first_name").val();
            garentor_gender=$("#gender option:selected").val();
            id_number=$("#id_number").val();
            if(first_name!=""){
                if(id_number!=""){
                    $("#garentor_name").val(first_name);
                    $('#garentor_gender option[value='+garentor_gender+']').attr('selected','selected');
                    $("#garentor_relation").val("Myself");
                    $("#national_id").val(id_number);
                    //Disable all the fields
                    $("#garentor_name").attr('readonly',true);
                    $("#garentor_gender").attr('readonly',true);
                    $("#garentor_relation").attr('readonly',true);
                    $("#national_id").attr('readonly',true);
                }else{
                    $(this).attr('checked',false);
                    alert("Please add ID number!");
                }
                

            }else{
                $(this).attr('checked',false);
                alert("Please Insert First Name!");
            }
        }
    }
    
});
//For datepicker
$('#dob').datepicker({
    duration: "fast",
    showAnim: "drop", 
    showOptions: {direction: "up"} 
});
});
</script>
       
             




