@extends('adminlte::page')

@section('title','View Feedbacks')
@section('content_header')
    <h1>Manage Feedbacks</h1>
@stop
@section('content')

<div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <strong>Manage Feedbacks</strong>
                    </div>
                    <div class="panel-body">
                        <a href="{{ url('/feedbacks/create') }}" class="btn btn-success btn-sm" title="Add New Blog">
                            <i class="fa fa-plus" aria-hidden="true"></i> Add New
                        </a>

                        {!! Form::open(['method' => 'GET', 'url' => '/feedbacks', 'class' => 'navbar-form navbar-right', 'role' => 'search'])  !!}
                        <div class="input-group">
                            <input type="text" class="form-control" name="search" placeholder="Search...">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                        </div>
                        {!! Form::close() !!}

                        <br/>
                        <br/>
                        <div class="table-responsive">
                        	<ul class="list-unstyled">
                        		@php $autoNum=1 @endphp    
                                @foreach($feedbacks as $feedback)
                        		<li> 
                                    {{ 'Q'.($autoNum++).'.' }}
                                   <a href="/feedbacks/{{$feedback->id}}/edit/">{!! $feedback->feedback_query !!}</a>
                        		</li>
                        		@endforeach
                        	</ul>                            	
                            <div class="pagination-wrapper"> 

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection