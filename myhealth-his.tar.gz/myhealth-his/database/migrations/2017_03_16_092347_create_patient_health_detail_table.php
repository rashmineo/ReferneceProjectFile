<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePatientHealthDetailTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('patient_health_detail', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('patient_id')->unsigned();
            $table->foreign('patient_id')->references('id')->on('patient_information')->onDelete('cascade');
            $table->enum('allergies_type',['FOOD ALLERGIES','SEASONAL ALLERGIES','PET ALLERGIES','DRUG ALLERGIES','OTHER'])->nullable();
            $table->string('allergens')->nullable();
            $table->text('medical_history')->nullable();
            $table->text('family_medical_history')->nullable();
            $table->text('imp_note')->nullable();
            $table->timestamps();
            $table->timestamp('deleted_at')->nullable();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('patient_health_detail');
    }
}
