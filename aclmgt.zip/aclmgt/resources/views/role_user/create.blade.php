@extends('layouts.app')

@section('title', 'Add User Role')

@section('content_header')
    <h1>Add User Role</h1>
@stop


@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Add User Role</div>
                    <div class="panel-body">
                        <a href="{{ url('/user-roles') }}" title="Back"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <br />
                        <br />
                        
                        {!! Form::open(['url' => '/user-roles', 'class' => 'form-horizontal', 'files' => true]) !!}

                        @include ('role_user.form')
                        
                        {!! Form::close() !!}

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
