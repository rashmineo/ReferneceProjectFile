<div class="form-group <?php echo e($errors->has('role_id') ? 'has-error' : ''); ?>">
    <?php echo Form::label('role_id', 'Role Name', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::select('role_id',$roles, null, ['class' => 'form-control','id'=>"role_id"]); ?>

        <?php echo $errors->first('role_id', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('user_id') ? 'has-error' : ''); ?>">
    <?php echo Form::label('user_id', 'User Name', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
         <?php echo Form::select('user_id',$users, null, ['class' => 'form-control','id'=>"user_id"]); ?>

        <?php echo $errors->first('user_id', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary']); ?>

    </div>
</div>