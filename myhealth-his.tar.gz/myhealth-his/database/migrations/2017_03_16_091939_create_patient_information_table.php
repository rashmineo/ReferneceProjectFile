<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePatientInformationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('patient_information', function (Blueprint $table) {
            $table->increments('id');
            $table->string('mrn');
            $table->string('first_name');
            $table->string('middle_name');
            $table->string('last_name');
            $table->string('guardian_name');
            $table->date('dob');
            $table->time('birth_time')->nullable();;
            $table->enum('gender', ['MALE', 'FEMALE','OTHER']);
            $table->enum('marital_status',['SINGLE','MARRIED','WIDOWED','DIVORCED','SEPRATED']);
            $table->enum('blood_group',['A+VE','B+VE','AB+VE','O+VE','O-VE']);
            $table->enum('religion',['HINDU','ISLAM','CHRISTIAN','SIKH','BUDDHISTH','JAIN','OTHER'])->nullable();
            $table->string('occupation')->nullable();
            $table->string('organization_name')->nullable();
            $table->string('profile_pic')->nullable();
            $table->timestamps();
            $table->timestamp('deleted_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('patient_information');
    }
}
