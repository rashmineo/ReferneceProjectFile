@extends('adminlte::page')

@section('title','Manage Travel Notices')

@section('conent_header')
<h1>Manage Travel Notices</h1>
@stop

@section('content')
<div class="container-fluid">
    
</div>
@endsection