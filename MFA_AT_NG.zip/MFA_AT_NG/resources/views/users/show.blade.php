@extends('adminlte::page')

@section('title','Manage Your Profile')
@section('content_header')
    <h1>Manage Your Profile</h1>
@stop
@section('content')

<div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <strong>Manage Your Profile</strong>
                    </div>
                    <div class="panel-body">
                        <a href="{{ url('/adminusers/') }}" class="btn btn-warning btn-xs" title="Add New Blog">
                            <i class="fa fa-arrow-left" aria-hidden="true"></i> Back
                        </a>
                        <br />
                        <br />
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <tbody>
                                    <tr>
                                        <th>ID</th><td>{{ $adminuser->id }}</td>
                                    </tr>
                                    <tr>
                                         <th>Title</th><td>{{ $adminuser->title }}</td>
                                    </tr> 
                                    <tr>
                                         <th>Name</th><td>{{ ucfirst($adminuser->first_name)." ". ucfirst($adminuser->last_name) }}</td>
                                    </tr> 
                                    <tr>
                                         <th>Email</th><td>{{ $adminuser->email }}</td>
                                    </tr> 
                                    <tr>
                                         <th>Phone No.</th><td>{{ $adminuser->phone_no}}</td>
                                    </tr> 
                                    <tr>
                                         <th>Country</th><td>{{ isset($adminuser->country->name) ? $adminuser->country->name : '-' }}</td>
                                    </tr> 
                                    <tr>
                                         <th>State</th><td>{{ isset($adminuser->state->name) ? $adminuser->state->name : '-' }}</td>
                                    </tr> 
                                    <tr>
                                         <th>City</th><td>{{ isset($adminuser->city->name) ? $adminuser->city->name : '-' }}</td>
                                    </tr> 
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection