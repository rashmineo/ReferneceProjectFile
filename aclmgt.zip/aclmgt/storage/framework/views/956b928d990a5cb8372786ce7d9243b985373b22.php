<?php $__env->startSection('title','Manage Role'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Manage Role</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <strong>Manage Role</strong>
                    </div>
                    <div class="panel-body">
                        <a href="<?php echo e(url('/user-roles/')); ?>" class="btn btn-warning btn-xs" title="Add New Blog">
                            <i class="fa fa-arrow-left" aria-hidden="true"></i> Back
                        </a>
                        <br />
                        <br />
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <tbody>
                                    <tr>
                                        <th>ID</th><td><?php echo e($userrole->id); ?></td>
                                    </tr>
                                    <tr>
                                         <th>User Name</th><td><?php echo e($userrole->user->name); ?></td>
                                    </tr> 
                                    <tr>
                                         <th>Role Name</th><td><?php echo e($userrole->role->name); ?></td>
                                    </tr>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>