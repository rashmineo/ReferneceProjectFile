<?php $__env->startSection('title','Add New Feedback'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default">
                <div class="panel-heading">Create New Feedback</div>
                    <div class="panel-body">
                    	<a href="<?php echo e(url('/feedbacks')); ?>" title="Back"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <br />
                        <br />

                        <?php echo Form::open(['url' => '/feedbacks', 'class' => 'form-horizontal', 'files' => true]); ?>


                        <?php echo $__env->make('feedbacks.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        <?php echo Form::close(); ?>

                 	</div>
            </div>    
        </div>    
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>