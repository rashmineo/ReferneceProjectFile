@extends('adminlte::page')

@section('title', 'Patients')

@section('content_header')
    <h1>Add New Patient</h1>
@stop


@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Create New Patient</div>
                    <div class="panel-body">
                        <a href="{{ url('/patient') }}" title="Back"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <!-- <br />
                        <br />
                         -->
                    </div>
                </div>
            </div>
        </div>
       <!--  @if ($errors->any())                            @foreach ($errors->all() as $error)                    {{ $error }}                @endforeach                    @endif -->
        {!! Form::open(['url' => '/patient', 'class' => 'form-horizontal', 'files' => true]) !!}

                        @include ('patient_information.form',['pageType' =>'create'])
                        
                        {!! Form::close() !!}
    </div>
@endsection
