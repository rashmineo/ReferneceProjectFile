<?php

namespace App\Http\Middleware;

use Closure;

class VerifyApiToken
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {   
        $success_flag = config('constants.success_flag');
        $data_missing = config('constants.data_missing');
        $api_key_missing = config('constants.api_key_missing');
        $invalid_data = config('constants.invalid_data');
        
        $api_secret_key = config('constants.api_secret_key');
        $auth_user = config('constants.auth_user');
        $auth_password = config('constants.auth_password');
        $url_string = $request->fullUrl();
        
        $api_key = hash_hmac('sha1', $url_string, $api_secret_key);
        
        $api_auth_user = !empty($request->header('username')) ? $request->header('username') : $request->header('php-auth-user');
        $api_auth_password = !empty($request->header('password')) ? $request->header('password') : $request->header('php-auth-pw');

         //return response($url_string); 

        //return response($api_key);
        //return response($request->header());
        //return response($request->header('Apikey'));
        //return response($api_auth_user);
        //return response($api_auth_password);
        //return response($request->all());
        //$api_key = 'main_hmac';
        //dd($api_key);
        
        $response_arr = array();
        
        if(empty($request->header('Apikey'))){
            
            $response_arr = array('status' => false,'status_code'=>$api_key_missing, 'message' => '401 unauthorized!, Apikey missing');
            return response($response_arr,401);
        }
        
        if(empty($api_auth_user) || empty($api_auth_password)){
            $response_arr = array('status' => false,'status_code'=>$api_key_missing, 'message' => '401 unauthorized!, Api Authentication details missing');
            return response($response_arr,401);
        }
        
        $validator = \Validator::make(['Apikey'=> $request->header('Apikey')],['Apikey'=>'required'],['Apikey.required'=>'The Apikey is required.']);
        
        $response_arr = array();
        
        if($validator->fails()){
            //return response($validator->errors()->all());
            $message = '';
            
            foreach($validator->errors()->all() as $error){
                if($message == ''){
                    $message.= $error;
                }else{
                    $message.= ','.$error;
                }
            }
            
            $response_arr = array('status' => false,'status_code'=>$api_key_missing, 'message' => $message);
            
            return response($response_arr,401);
        }
        
        if($request->header('Apikey') != $api_key){
            
            $response_arr = array('status' => false, 'status_code'=>$api_key_missing,'message' => 'Invalid Apikey.');
            return response($response_arr,401);
        }
        
        if(!($api_auth_user == $auth_user && $api_auth_password == $auth_password)){
            $response_arr = array('status' => false, 'status_code'=>$api_key_missing,'message' => 'Invalid Api Authentication credentials.');
            return response($response_arr,401);
        }
        
        return $next($request);
    }
}
