<?php $__env->startSection('title','Faqs'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Manage FAQs</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <strong>Manage FAQs</strong>
                    </div>
                    <div class="panel-body">
                        <a href="<?php echo e(url('/faqs/create')); ?>" class="btn btn-success btn-sm" title="Add New Blog">
                            <i class="fa fa-plus" aria-hidden="true"></i> Add New FAQ
                        </a>

                        <?php echo Form::open(['method' => 'GET', 'url' => '/faqs', 'class' => 'navbar-form navbar-right', 'role' => 'search']); ?>

                        <div class="input-group">
                            <input type="text" class="form-control" name="search" placeholder="Search...">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                        </div>
                        <?php echo Form::close(); ?>


                        <br/>
                        <br/>
                        <div class="col-md-12">
                        <div class="table-responsive">
                        	<ul class="list-unstyled">
                        		<?php  $autoNum=1  ?>    
                                <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        		<li style="line-height: 25px"> 
                                    <?php echo e('Q'.($autoNum++).'.'); ?>

                                   <a href="/faqs/<?php echo e($faq->id); ?>/edit/"><?php echo $faq->faq_query; ?></a>
                        		</li>
                        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        	</ul>                            	
                            <div class="pagination-wrapper"> 

                            </div>
                        </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>