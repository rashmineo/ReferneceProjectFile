<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePatientInsuranceTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('patient_insurance', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('patient_id')->unsigned();
            $table->foreign('patient_id')->references('id')->on('patient_information')->onDelete('cascade');
            $table->string('garentor_name');
            $table->enum('garentor_gender',['MALE','FEMALE','OTHER']);
            $table->string('garentor_relation');
            $table->string('national_id')->nullable();
            $table->string('policy_number')->nullable();
            $table->string('policy_name')->nullable();
            $table->string('agency')->nullable();
            $table->timestamps();
            $table->timestamp('deleted_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('patient_insurance');
    }
}
