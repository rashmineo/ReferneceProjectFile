@extends('layouts.app')
<style type="text/css">
	.profile-img{max-width: 150px; border: 5px solid #fff; box-shadow: 0 2px 2px rgba(0,0,0,0.2);border-radius: 100%;}
</style>

@section('content')
<div class="row">
	<div class="col-md-6 col-md-offset-3">
		<div class="panel panel-default">
			<div class="panel-body text-center">
				<img src="https://4.bp.blogspot.com/-uxL3cu5k_ho/VfbwSPt0izI/AAAAAAAAKrE/4k2EVA4J8YI/s1600/doll-girl-cute-heart-glasses-4838.jpg" class="profile-img">
				<h1>{{$user->name}}</h1>
				<h5>{{$user->email}}</h5>
				<h5>{{$user->dob->format('l j F Y')}} ({{$user->dob->age}} years old) </h5>

				<button class="btn btn-success">Follow</button>
			</div>
		</div>
	</div>
</div>

@endsection
