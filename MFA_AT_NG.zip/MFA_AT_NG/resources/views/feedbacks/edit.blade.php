@extends('adminlte::page')

@section('title','Edit Feedback')

@section('content_header')
    <h1>Edit Feedback</h1>
@stop
@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Edit Feedback #{{ $feedback->id }}</div>
                <div class="panel-body">
                {!! 

                Form::model($feedback, [
                	'method' => 'PATCH',
                    'url' => ['/feedbacks', $feedback->id],
                    'class' => 'form-horizontal',
                    'files' => true
                ])
                !!}
                @include ('feedbacks.form', ['submitButtonText' => 'Update'])

                        {!! Form::close() !!}
                </div>
            </div>    
		</div>
	</div>
</div>			


@endsection
