@extends('adminlte::page')

@section('title','View Users')
@section('content_header')
    <h1>Manage Admin Users</h1>
@stop
@section('content')

<div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <strong>Manage Admin Users</strong>
                    </div>
                    <div class="panel-body">
                        <a href="{{ url('/adminusers/create') }}" class="btn btn-success btn-sm" title="Add New Blog">
                            <i class="fa fa-plus" aria-hidden="true"></i> Add New User
                        </a>

                        {!! Form::open(['method' => 'GET', 'url' => '/adminusers', 'class' => 'navbar-form navbar-right', 'role' => 'search'])  !!}
                        <div class="input-group">
                            <input type="text" class="form-control" name="search" placeholder="Search...">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                        </div>
                        {!! Form::close() !!}

                        <br/>
                        <br/>
        
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Title</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone No.</th>
                                        <th>Country</th>
                                        <th>State</th>
                                        <th>City</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                @foreach($adminusers as $adminuser)
                                    <tr>
                                    
                                        <td>{{ $adminuser->id }}</td>
                                        <td>{{ $adminuser->title }}</td>
                                        <td>{{ ucfirst($adminuser->first_name)." ". ucfirst($adminuser->last_name) }}</td>
                                        <td>{{ $adminuser->email }}</td>
                                        <td>{{ $adminuser->phone_no}}</td>
                                        <td>{{ isset($adminuser->country->name) ? $adminuser->country->name : '-' }}</td>
                                        <td>{{ isset($adminuser->state->name) ? $adminuser->state->name : '-' }}</td>
                                        <td>{{ isset($adminuser->city->name) ? $adminuser->city->name : '-' }}</td>
                                        <td>
                                            <a href="{{ url('/adminusers/' . $adminuser->id) }}" title="View User"><button class="btn btn-info btn-xs"><i class="fa fa-eye" aria-hidden="true"></i> View</button></a>
                                            <a href="{{ url('/adminusers/' . $adminuser->id . '/edit') }}" title="Edit User"><button class="btn btn-primary btn-xs"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</button></a>
                                            {!! Form::open([
                                                'method'=>'DELETE',
                                                'url' => ['/adminusers', $adminuser->id],
                                                'style' => 'display:inline'
                                            ]) !!}
                                                {!! Form::button('<i class="fa fa-trash-o" aria-hidden="true"></i> Delete', array(
                                                        'type' => 'submit',
                                                        'class' => 'btn btn-danger btn-xs',
                                                        'title' => 'Delete User',
                                                        'onclick'=>'return confirm("Confirm delete?")'
                                                )) !!}
                                            {!! Form::close() !!}
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                            <div class="pagination-wrapper"> {!! $adminusers->appends(['search' => Request::get('search')])->render() !!} </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection