<?php

namespace App\Traits;
use App\Member;

trait AuthorizesApiRequests
{
    public function authorizeApiUser($authtoken=null){
        
        $success_flag = config('constants.success_flag');
        $data_missing = config('constants.data_missing');
        $api_key_missing = config('constants.api_key_missing');
        $forbidden_access = config('constants.forbidden_access');
        $invalid_data = config('constants.invalid_data');        
        
        $response_arr = array();
        
        if(empty($authtoken) || $authtoken==null){            
            $response_arr = array('status' => false,'status_code'=>$api_key_missing, 'message' => '401 unauthorized!. Missing header authtoken.');
            header('HTTP/1.1 401 Unauthorized');            
            echo json_encode($response_arr);
            exit();
        }
        
        $member = Member::with(['country','state','city'=>function($query){ $query->select(['id','name','state_id']); }])->select(['id','title','name','first_name','last_name','gender','dob','address','country_id','state_id','city_id','email','phone_no','nationality','auth_token'])->where('auth_token',$authtoken)->first();
        
        if($member == null){
            $response_arr = array('status' => false,'status_code'=>$forbidden_access, 'message' => '403 unauthorized!. Header authentication failed.');
            header('HTTP/1.1 403 Unauthorized');            
            echo json_encode($response_arr);
            exit();
            //return response($response_arr,$forbidden_access); 
        }
        
        return $member;
    }
}
