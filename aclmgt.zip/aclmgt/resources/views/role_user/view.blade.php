@extends('layouts.app')

@section('title','Manage Role')
@section('content_header')
    <h1>Manage Role</h1>
@stop
@section('content')

<div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <strong>Manage Role</strong>
                    </div>
                    <div class="panel-body">
                        <a href="{{ url('/user-roles/') }}" class="btn btn-warning btn-xs" title="Add New Blog">
                            <i class="fa fa-arrow-left" aria-hidden="true"></i> Back
                        </a>
                        <br />
                        <br />
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <tbody>
                                    <tr>
                                        <th>ID</th><td>{{ $userrole->id }}</td>
                                    </tr>
                                    <tr>
                                         <th>User Name</th><td>{{ $userrole->user->name }}</td>
                                    </tr> 
                                    <tr>
                                         <th>Role Name</th><td>{{ $userrole->role->name }}</td>
                                    </tr>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection