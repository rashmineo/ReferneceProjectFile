<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Country;
use App\State;
use App\City;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;

class LocationsController extends Controller
{
    public function getCountries(Request $request){

        //dd('test');
        
        $countries = Country::orderBy('name','asc')->pluck('name','id')->toArray();
        if(count($countries)>0){
            $data = array('status'=>'success', 'tp'=>1, 'msg'=>"Countries fetched successfully.", 'result'=>$countries);
        }else{
            $data = array('status'=>'error', 'tp'=>0, 'msg'=>'Country list not exists');
        }
        
        return response($data,201);
    }
    
    public function getStates(Request $request){                
       
        $validator = Validator::make($request->all(),['country_id'=>'required']);
                
        if (!$validator->fails()){
            $states = State::where('country_id',$request->input('country_id'))->orderBy('name','asc')->pluck('name','id')->toArray();
            if(count($states)>0){
                $data = array('status'=>'success', 'tp'=>1, 'msg'=>"States fetched successfully.", 'result'=>$states);
            }else{
                $data = array('status'=>'error', 'tp'=>0, 'msg'=>'States list not exists');
            }
        }else{
            $data = array('status'=>'error', 'tp'=>0,'result'=>[], 'msg'=>$validator->messages());
        }
        
        return response($data,201);
    }
    
    public function getCities(Request $request){
        
        $validator = Validator::make($request->all(),['state_id'=>'required']);
                
        if (!$validator->fails()){
        
            $cities = City::where('state_id',$request->input('state_id'))->orderBy('name','asc')->pluck('name','id')->toArray();
            if(count($cities)>0){
                $data = array('status'=>'success', 'tp'=>1, 'msg'=>"Cities fetched successfully.", 'result'=>$cities);
            }else{
                $data = array('status'=>'error', 'tp'=>0, 'msg'=>'Cities list not exists');
            }
        
        }else{
            $data = array('status'=>'error', 'tp'=>0,'result'=>[], 'msg'=>$validator->messages());
        }
        
        return response($data,201);
    }
}
