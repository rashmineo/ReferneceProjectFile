<?php

namespace App\Providers;
use Carbon\Carbon;
use Illuminate\Support\ServiceProvider;
use View;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
        $age = Carbon::createFromDate(1990,11,5)->age;
        
        View::share('age',$age);
        View::share('myname','Amisha');
        /*View::composer('*',function(){
            $view->with('auth',Auth::user());
        });*/
    }
}
