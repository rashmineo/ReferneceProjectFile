<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePatientContactTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('patient_contact', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('patient_id')->unsigned();
            $table->foreign('patient_id')->references('id')->on('patient_information')->onDelete('cascade');
            $table->text('current_address');
            $table->integer('current_city_id');
            $table->integer('current_state_id');
            $table->integer('current_country_id');
            $table->string('current_pincode');
            $table->text('permanent_address')->nullable();
            $table->integer('permanent_country_id')->nullable();
            $table->integer('permanent_state_id')->nullable();
            $table->integer('permanent_city_id')->nullable();
            $table->string('permanent_pincode')->nullable();
            $table->string('phone_number');
            $table->string('alt_phone_number')->nullable();
            $table->string('email');
            $table->string('nationality')->nullable();
            $table->enum('id_type',['AADHAR CARD','PAN CARD','ELECTION CARD','PASSPORT'])->nullable();
            $table->string('id_number')->nullable();
            $table->timestamps();
            $table->timestamp('deleted_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('patient_contact');
    }
}
