-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 10, 2017 at 06:12 PM
-- Server version: 5.7.17-0ubuntu0.16.04.1
-- PHP Version: 7.0.15-0ubuntu0.16.04.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aclmgt`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteStudentRecord` (IN `StudentId` INT(11))  BEGIN
DELETE FROM tbl_students WHERE `student_id` = StudentId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllStudents` ()  BEGIN
   SELECT *  FROM tbl_students ;
   END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertStudentRecord` (IN `StudentFirstName` VARCHAR(200) CHARSET utf8, IN `StudentLastName` VARCHAR(200) CHARSET utf8, IN `StudentEmail` VARCHAR(50) CHARSET utf8)  BEGIN
 insert into tbl_students (`first_name`,`last_name`,`email`) VALUES (StudentFirstName, StudentLastName, StudentEmail) ; 
 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateStudentRecord` (IN `StudentId` INT(11), IN `StudentName` VARCHAR(200))  BEGIN
UPDATE tbl_students SET `first_name` = StudentName WHERE `student_id` = StudentId;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2015_02_07_172606_create_roles_table', 2),
(4, '2015_02_07_172633_create_role_user_table', 2),
(5, '2015_02_07_172649_create_permissions_table', 2),
(6, '2015_02_07_172657_create_permission_role_table', 2),
(7, '2015_02_17_152439_create_permission_user_table', 2),
(8, '2015_11_30_232041_bigint_user_keys', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `inherit_id` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `inherit_id`, `name`, `slug`, `description`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Create', 'create', 'Permission to create', NULL, NULL),
(2, NULL, 'Delete', 'delete', 'Delete permission', NULL, NULL),
(3, NULL, 'Update', 'update', 'update permisssion', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `permission_role`
--

CREATE TABLE `permission_role` (
  `id` int(10) UNSIGNED NOT NULL,
  `permission_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_role`
--

INSERT INTO `permission_role` (`id`, `permission_id`, `role_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, NULL, NULL),
(2, 2, 1, NULL, NULL),
(3, 3, 1, NULL, NULL),
(4, 1, 6, NULL, NULL),
(5, 3, 6, NULL, NULL),
(6, 3, 5, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `permission_user`
--

CREATE TABLE `permission_user` (
  `id` int(10) UNSIGNED NOT NULL,
  `permission_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `content`, `category`, `created_at`, `updated_at`) VALUES
(1, 'post', 'post content', '0', '2017-03-09 07:21:11', '2017-03-09 07:21:11');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `slug`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', 'administrator', 'This is an admin role', '2017-03-09 01:26:49', '2017-03-09 01:26:49'),
(5, 'Moderator', 'moderator', 'moderator', '2017-03-09 04:01:17', '2017-03-09 04:01:17'),
(6, 'Author', 'author', 'author', '2017-03-09 06:06:37', '2017-03-09 06:06:37');

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE `role_user` (
  `id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_user`
--

INSERT INTO `role_user` (`id`, `role_id`, `user_id`, `created_at`, `updated_at`) VALUES
(4, 1, 14, '2017-03-09 04:23:24', '2017-03-09 05:16:30'),
(5, 5, 9, '2017-03-09 06:07:01', '2017-03-09 06:07:01'),
(6, 6, 20, '2017-03-09 06:07:12', '2017-03-09 06:07:12');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_students`
--

CREATE TABLE `tbl_students` (
  `student_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_students`
--

INSERT INTO `tbl_students` (`student_id`, `first_name`, `last_name`, `email`) VALUES
(1, 'Vivek', 'Johari', 'vivek@abc.com'),
(2, 'Pankaj', 'Kumar', 'pankaj@abc.com'),
(3, 'Amit', 'Singh', 'amit@abc.com'),
(4, 'Manish', 'Kumar', 'manish@abc.comm'),
(5, 'Abhishek', 'Singh', 'abhishek@abc.com'),
(8, 'Logan', 'Roxy', 'logan@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Allen', 'allen@gmail.com', '$2y$10$qFUgQi/r3mv6jSvv6zbHZe/yOhX17xSvwSJdHml7b58DZNbHIDSde', NULL, '2017-03-09 00:11:52', '2017-03-09 00:11:52'),
(2, 'Mrs. Elinore Conn DDS', 'jewell.barrows@example.org', '$2y$10$sljO5dYHn8uO4NyXzN5v/eDBAk2u0VnGzB3Ro0exbZ10hCGiA5ZoC', 'fem5U3J6Vh', '2017-03-09 03:54:47', '2017-03-09 03:54:47'),
(3, 'Prof. Anais Pollich', 'xconn@example.org', '$2y$10$sljO5dYHn8uO4NyXzN5v/eDBAk2u0VnGzB3Ro0exbZ10hCGiA5ZoC', 'WuxJ90YP2z', '2017-03-09 03:54:47', '2017-03-09 03:54:47'),
(4, 'Prof. Magdalen Pacocha DDS', 'chance.pagac@example.net', '$2y$10$sljO5dYHn8uO4NyXzN5v/eDBAk2u0VnGzB3Ro0exbZ10hCGiA5ZoC', 'FmrsUZ1Zao', '2017-03-09 03:54:47', '2017-03-09 03:54:47'),
(5, 'Lourdes Schuppe', 'toy.delia@example.net', '$2y$10$sljO5dYHn8uO4NyXzN5v/eDBAk2u0VnGzB3Ro0exbZ10hCGiA5ZoC', '1Zqqf5Itkg', '2017-03-09 03:54:47', '2017-03-09 03:54:47'),
(6, 'Dr. Vaughn Von Sr.', 'laurianne71@example.org', '$2y$10$sljO5dYHn8uO4NyXzN5v/eDBAk2u0VnGzB3Ro0exbZ10hCGiA5ZoC', 'mNBNFR5PHv', '2017-03-09 03:54:47', '2017-03-09 03:54:47'),
(7, 'Lonie Upton MD', 'carolyn.botsford@example.com', '$2y$10$sljO5dYHn8uO4NyXzN5v/eDBAk2u0VnGzB3Ro0exbZ10hCGiA5ZoC', 'ajjeHWxo5c', '2017-03-09 03:54:47', '2017-03-09 03:54:47'),
(8, 'Prof. Christiana West', 'emerald56@example.com', '$2y$10$sljO5dYHn8uO4NyXzN5v/eDBAk2u0VnGzB3Ro0exbZ10hCGiA5ZoC', 'J75b8r2BpC', '2017-03-09 03:54:47', '2017-03-09 03:54:47'),
(9, 'Angela Murazik', 'roxane54@example.com', '$2y$10$sljO5dYHn8uO4NyXzN5v/eDBAk2u0VnGzB3Ro0exbZ10hCGiA5ZoC', 'HCqsAubuCK', '2017-03-09 03:54:47', '2017-03-09 03:54:47'),
(10, 'Charles Hauck', 'johnpaul52@example.com', '$2y$10$sljO5dYHn8uO4NyXzN5v/eDBAk2u0VnGzB3Ro0exbZ10hCGiA5ZoC', 'DNtfbJL2w5', '2017-03-09 03:54:47', '2017-03-09 03:54:47'),
(11, 'Raina Spencer', 'halvorson.bradford@example.net', '$2y$10$sljO5dYHn8uO4NyXzN5v/eDBAk2u0VnGzB3Ro0exbZ10hCGiA5ZoC', 'Apf34GW0dh', '2017-03-09 03:54:47', '2017-03-09 03:54:47'),
(12, 'Marilou DuBuque', 'vwillms@example.com', '$2y$10$sljO5dYHn8uO4NyXzN5v/eDBAk2u0VnGzB3Ro0exbZ10hCGiA5ZoC', 'tEx2mJ3GFh', '2017-03-09 03:54:47', '2017-03-09 03:54:47'),
(13, 'Virgie Willms', 'idach@example.com', '$2y$10$sljO5dYHn8uO4NyXzN5v/eDBAk2u0VnGzB3Ro0exbZ10hCGiA5ZoC', 'ogc1II49dD', '2017-03-09 03:54:47', '2017-03-09 03:54:47'),
(14, 'Lilla Goldner', 'carmstrong@example.com', '$2y$10$sljO5dYHn8uO4NyXzN5v/eDBAk2u0VnGzB3Ro0exbZ10hCGiA5ZoC', 'M9dbD12yrm', '2017-03-09 03:54:47', '2017-03-09 03:54:47'),
(15, 'Miss Marisol Lind PhD', 'pollich.rosina@example.net', '$2y$10$sljO5dYHn8uO4NyXzN5v/eDBAk2u0VnGzB3Ro0exbZ10hCGiA5ZoC', 'XCHm19cja2', '2017-03-09 03:54:47', '2017-03-09 03:54:47'),
(16, 'Elmira Olson', 'deborah.cummerata@example.net', '$2y$10$sljO5dYHn8uO4NyXzN5v/eDBAk2u0VnGzB3Ro0exbZ10hCGiA5ZoC', 'c5C1LQDOOu', '2017-03-09 03:54:47', '2017-03-09 03:54:47'),
(17, 'Prof. Billy Smitham DVM', 'bkunze@example.com', '$2y$10$sljO5dYHn8uO4NyXzN5v/eDBAk2u0VnGzB3Ro0exbZ10hCGiA5ZoC', 'VUbqMjDROS', '2017-03-09 03:54:47', '2017-03-09 03:54:47'),
(18, 'Esteban Kertzmann', 'nathanael.auer@example.com', '$2y$10$sljO5dYHn8uO4NyXzN5v/eDBAk2u0VnGzB3Ro0exbZ10hCGiA5ZoC', 'COSh2AzYiw', '2017-03-09 03:54:48', '2017-03-09 03:54:48'),
(19, 'Jamil Raynor', 'schneider.aubree@example.net', '$2y$10$sljO5dYHn8uO4NyXzN5v/eDBAk2u0VnGzB3Ro0exbZ10hCGiA5ZoC', 'AHOq00h1a9', '2017-03-09 03:54:48', '2017-03-09 03:54:48'),
(20, 'Otho Stracke Sr.', 'vkuhn@example.org', '$2y$10$sljO5dYHn8uO4NyXzN5v/eDBAk2u0VnGzB3Ro0exbZ10hCGiA5ZoC', 'W9PvXhshkb', '2017-03-09 03:54:48', '2017-03-09 03:54:48'),
(21, 'Makenzie Schuppe', 'sydney.harris@example.org', '$2y$10$sljO5dYHn8uO4NyXzN5v/eDBAk2u0VnGzB3Ro0exbZ10hCGiA5ZoC', '6QWlwUdrXn', '2017-03-09 03:54:48', '2017-03-09 03:54:48'),
(22, 'Prof. Aleen Cummings IV', 'wryan@example.com', '$2y$10$a3is.ay8/yld8viDBicZVum3nZLdwG6yklsvwj0JkoclpVprWP2au', 'tN586mPI6k', '2017-03-09 03:56:13', '2017-03-09 03:56:13'),
(23, 'Izaiah Waelchi', 'fhirthe@example.net', '$2y$10$a3is.ay8/yld8viDBicZVum3nZLdwG6yklsvwj0JkoclpVprWP2au', 'JLMqVGHWq3', '2017-03-09 03:56:13', '2017-03-09 03:56:13'),
(24, 'Prof. Ricardo Schumm MD', 'lizzie62@example.net', '$2y$10$a3is.ay8/yld8viDBicZVum3nZLdwG6yklsvwj0JkoclpVprWP2au', 'qQ9lToGScs', '2017-03-09 03:56:13', '2017-03-09 03:56:13'),
(25, 'Moses Funk', 'reichel.meagan@example.net', '$2y$10$a3is.ay8/yld8viDBicZVum3nZLdwG6yklsvwj0JkoclpVprWP2au', '47ESmSyxfO', '2017-03-09 03:56:13', '2017-03-09 03:56:13'),
(26, 'Jazmyn Cruickshank', 'guy02@example.org', '$2y$10$a3is.ay8/yld8viDBicZVum3nZLdwG6yklsvwj0JkoclpVprWP2au', 'N3QgjEHg1D', '2017-03-09 03:56:13', '2017-03-09 03:56:13'),
(27, 'Thelma Rohan', 'dayton.ledner@example.net', '$2y$10$a3is.ay8/yld8viDBicZVum3nZLdwG6yklsvwj0JkoclpVprWP2au', 'd3Fs3XJysG', '2017-03-09 03:56:13', '2017-03-09 03:56:13'),
(28, 'Mrs. Jacynthe Mitchell DDS', 'lgulgowski@example.com', '$2y$10$a3is.ay8/yld8viDBicZVum3nZLdwG6yklsvwj0JkoclpVprWP2au', 'MXU9KbOMiP', '2017-03-09 03:56:13', '2017-03-09 03:56:13'),
(29, 'Dorcas Morissette', 'hobart51@example.com', '$2y$10$a3is.ay8/yld8viDBicZVum3nZLdwG6yklsvwj0JkoclpVprWP2au', 'UNDuDgNi9B', '2017-03-09 03:56:13', '2017-03-09 03:56:13'),
(30, 'Jaylon Wunsch', 'pdare@example.net', '$2y$10$a3is.ay8/yld8viDBicZVum3nZLdwG6yklsvwj0JkoclpVprWP2au', 'p4UpecF4o2', '2017-03-09 03:56:13', '2017-03-09 03:56:13'),
(31, 'Mr. Luigi Bartell Jr.', 'will.vickie@example.net', '$2y$10$a3is.ay8/yld8viDBicZVum3nZLdwG6yklsvwj0JkoclpVprWP2au', '4kXTMmD3wg', '2017-03-09 03:56:13', '2017-03-09 03:56:13'),
(32, 'Cody Emard', 'lockman.pierre@example.org', '$2y$10$a3is.ay8/yld8viDBicZVum3nZLdwG6yklsvwj0JkoclpVprWP2au', 'b0afntr4FA', '2017-03-09 03:56:13', '2017-03-09 03:56:13'),
(33, 'Jamarcus Legros', 'frami.damien@example.com', '$2y$10$a3is.ay8/yld8viDBicZVum3nZLdwG6yklsvwj0JkoclpVprWP2au', 'phsHekVTG7', '2017-03-09 03:56:13', '2017-03-09 03:56:13'),
(34, 'Ms. Alanna Smith', 'istamm@example.org', '$2y$10$a3is.ay8/yld8viDBicZVum3nZLdwG6yklsvwj0JkoclpVprWP2au', 'GQNXerNq4z', '2017-03-09 03:56:13', '2017-03-09 03:56:13'),
(35, 'Greg Schmitt', 'kyle39@example.org', '$2y$10$a3is.ay8/yld8viDBicZVum3nZLdwG6yklsvwj0JkoclpVprWP2au', 'uOfv7WaV5P', '2017-03-09 03:56:13', '2017-03-09 03:56:13'),
(36, 'Mrs. Aliza Nikolaus', 'wgutmann@example.org', '$2y$10$a3is.ay8/yld8viDBicZVum3nZLdwG6yklsvwj0JkoclpVprWP2au', 'DzyIf0tvN1', '2017-03-09 03:56:13', '2017-03-09 03:56:13'),
(37, 'Ms. Treva Bergnaum', 'arlene.mcclure@example.org', '$2y$10$a3is.ay8/yld8viDBicZVum3nZLdwG6yklsvwj0JkoclpVprWP2au', 'Cgmt1MNbK6', '2017-03-09 03:56:13', '2017-03-09 03:56:13'),
(38, 'Ms. Kaylee Zulauf', 'maegan.hammes@example.org', '$2y$10$a3is.ay8/yld8viDBicZVum3nZLdwG6yklsvwj0JkoclpVprWP2au', 'X7LoJbPVMx', '2017-03-09 03:56:13', '2017-03-09 03:56:13'),
(39, 'Hester McClure', 'pgreenholt@example.com', '$2y$10$a3is.ay8/yld8viDBicZVum3nZLdwG6yklsvwj0JkoclpVprWP2au', 'fPo5hdjilI', '2017-03-09 03:56:13', '2017-03-09 03:56:13'),
(40, 'Jana Johnston IV', 'mayer.seamus@example.net', '$2y$10$a3is.ay8/yld8viDBicZVum3nZLdwG6yklsvwj0JkoclpVprWP2au', '3Oev1624N1', '2017-03-09 03:56:14', '2017-03-09 03:56:14'),
(41, 'Mr. Olin Bode DVM', 'pmayert@example.org', '$2y$10$a3is.ay8/yld8viDBicZVum3nZLdwG6yklsvwj0JkoclpVprWP2au', '6fX85Yaopx', '2017-03-09 03:56:14', '2017-03-09 03:56:14'),
(42, 'Mireille Greenfelder II', 'kuvalis.lucie@example.org', '$2y$10$uqWSoG08acxSQnS.veQ0teIvdyrPrUpR2Xfc4y.VhatQwuKauDFR6', '66525jclKB', '2017-03-09 03:57:52', '2017-03-09 03:57:52'),
(43, 'Aracely Nikolaus', 'dkemmer@example.org', '$2y$10$uqWSoG08acxSQnS.veQ0teIvdyrPrUpR2Xfc4y.VhatQwuKauDFR6', 'IT7xeqZufH', '2017-03-09 03:57:52', '2017-03-09 03:57:52'),
(44, 'Prof. Sibyl Cassin', 'abraham.spencer@example.net', '$2y$10$uqWSoG08acxSQnS.veQ0teIvdyrPrUpR2Xfc4y.VhatQwuKauDFR6', 'RnjTkxC4Cr', '2017-03-09 03:57:52', '2017-03-09 03:57:52'),
(45, 'Keenan Hayes', 'alvera65@example.org', '$2y$10$uqWSoG08acxSQnS.veQ0teIvdyrPrUpR2Xfc4y.VhatQwuKauDFR6', 'nSWqlxKdvi', '2017-03-09 03:57:52', '2017-03-09 03:57:52'),
(46, 'Mohammad O\'Keefe', 'rickey.marquardt@example.com', '$2y$10$uqWSoG08acxSQnS.veQ0teIvdyrPrUpR2Xfc4y.VhatQwuKauDFR6', 'dDTm3bieqj', '2017-03-09 03:57:52', '2017-03-09 03:57:52'),
(47, 'Miss Myrna Turner DDS', 'jcartwright@example.com', '$2y$10$uqWSoG08acxSQnS.veQ0teIvdyrPrUpR2Xfc4y.VhatQwuKauDFR6', 'je6lcpCval', '2017-03-09 03:57:52', '2017-03-09 03:57:52'),
(48, 'Jalyn Moore', 'gust48@example.com', '$2y$10$uqWSoG08acxSQnS.veQ0teIvdyrPrUpR2Xfc4y.VhatQwuKauDFR6', 'KS8fDDrmLs', '2017-03-09 03:57:52', '2017-03-09 03:57:52'),
(49, 'Kristin Brakus II', 'terence28@example.com', '$2y$10$uqWSoG08acxSQnS.veQ0teIvdyrPrUpR2Xfc4y.VhatQwuKauDFR6', 't6Za1jDekK', '2017-03-09 03:57:52', '2017-03-09 03:57:52'),
(50, 'Vincent Davis', 'mittie35@example.org', '$2y$10$uqWSoG08acxSQnS.veQ0teIvdyrPrUpR2Xfc4y.VhatQwuKauDFR6', 'Hehoma0cCm', '2017-03-09 03:57:52', '2017-03-09 03:57:52'),
(51, 'Kyle Rath III', 'mwilkinson@example.org', '$2y$10$uqWSoG08acxSQnS.veQ0teIvdyrPrUpR2Xfc4y.VhatQwuKauDFR6', 'FkPiLUSF8e', '2017-03-09 03:57:52', '2017-03-09 03:57:52'),
(52, 'Briana Morar IV', 'gerhold.jay@example.com', '$2y$10$uqWSoG08acxSQnS.veQ0teIvdyrPrUpR2Xfc4y.VhatQwuKauDFR6', 'jqJBToMbrH', '2017-03-09 03:57:52', '2017-03-09 03:57:52'),
(53, 'Herminio Keeling', 'streich.samir@example.com', '$2y$10$uqWSoG08acxSQnS.veQ0teIvdyrPrUpR2Xfc4y.VhatQwuKauDFR6', 'Xmykeq56YB', '2017-03-09 03:57:53', '2017-03-09 03:57:53'),
(54, 'Ceasar Bogan', 'ilynch@example.net', '$2y$10$uqWSoG08acxSQnS.veQ0teIvdyrPrUpR2Xfc4y.VhatQwuKauDFR6', 'Pwj5TFxa1w', '2017-03-09 03:57:53', '2017-03-09 03:57:53'),
(55, 'Dr. Trevor Robel MD', 'lenora56@example.net', '$2y$10$uqWSoG08acxSQnS.veQ0teIvdyrPrUpR2Xfc4y.VhatQwuKauDFR6', 'ybgKVZz3Nt', '2017-03-09 03:57:53', '2017-03-09 03:57:53'),
(56, 'Hortense Cremin', 'qwyman@example.org', '$2y$10$uqWSoG08acxSQnS.veQ0teIvdyrPrUpR2Xfc4y.VhatQwuKauDFR6', 'l855hHoUWb', '2017-03-09 03:57:53', '2017-03-09 03:57:53'),
(57, 'Dr. Sheila Cronin I', 'melba.leuschke@example.net', '$2y$10$uqWSoG08acxSQnS.veQ0teIvdyrPrUpR2Xfc4y.VhatQwuKauDFR6', 'M8iOXuYV9H', '2017-03-09 03:57:53', '2017-03-09 03:57:53'),
(58, 'Audrey Hilll', 'kshlerin.oral@example.org', '$2y$10$uqWSoG08acxSQnS.veQ0teIvdyrPrUpR2Xfc4y.VhatQwuKauDFR6', 'cUfcKmLqrQ', '2017-03-09 03:57:53', '2017-03-09 03:57:53'),
(59, 'Dr. Davonte Schiller IV', 'griffin.nader@example.net', '$2y$10$uqWSoG08acxSQnS.veQ0teIvdyrPrUpR2Xfc4y.VhatQwuKauDFR6', 'TO43FT2i14', '2017-03-09 03:57:53', '2017-03-09 03:57:53'),
(60, 'Dr. Tomasa Borer I', 'julianne.morar@example.net', '$2y$10$uqWSoG08acxSQnS.veQ0teIvdyrPrUpR2Xfc4y.VhatQwuKauDFR6', 'CVa8aRL8EW', '2017-03-09 03:57:53', '2017-03-09 03:57:53'),
(61, 'Pinkie Halvorson', 'hauck.henderson@example.com', '$2y$10$uqWSoG08acxSQnS.veQ0teIvdyrPrUpR2Xfc4y.VhatQwuKauDFR6', '9seGbWAJBn', '2017-03-09 03:57:53', '2017-03-09 03:57:53'),
(62, 'Sabina Sauer', 'jeffery33@example.org', '$2y$10$Ohrj.SEBkG2jrcvA4p7AXOxxCAVYZPy9iuoJw.Th1J1kR21jxEgxm', 'Y7uVqZ3fit', '2017-03-09 03:58:19', '2017-03-09 03:58:19'),
(63, 'Margarita Koelpin', 'vance97@example.net', '$2y$10$Ohrj.SEBkG2jrcvA4p7AXOxxCAVYZPy9iuoJw.Th1J1kR21jxEgxm', 'koHy8bxPdD', '2017-03-09 03:58:19', '2017-03-09 03:58:19'),
(64, 'Jeanette Wiegand', 'mcglynn.neil@example.net', '$2y$10$Ohrj.SEBkG2jrcvA4p7AXOxxCAVYZPy9iuoJw.Th1J1kR21jxEgxm', 'DiTHxzg21e', '2017-03-09 03:58:19', '2017-03-09 03:58:19'),
(65, 'Sammie Batz', 'adams.duncan@example.org', '$2y$10$Ohrj.SEBkG2jrcvA4p7AXOxxCAVYZPy9iuoJw.Th1J1kR21jxEgxm', 'b82DmUcxTZ', '2017-03-09 03:58:19', '2017-03-09 03:58:19'),
(66, 'Caitlyn Prohaska', 'green.wisoky@example.org', '$2y$10$Ohrj.SEBkG2jrcvA4p7AXOxxCAVYZPy9iuoJw.Th1J1kR21jxEgxm', 'bFKyGMBBGN', '2017-03-09 03:58:20', '2017-03-09 03:58:20'),
(67, 'Augustus Pfannerstill', 'predovic.dovie@example.com', '$2y$10$Ohrj.SEBkG2jrcvA4p7AXOxxCAVYZPy9iuoJw.Th1J1kR21jxEgxm', 'ONINKRxWtF', '2017-03-09 03:58:20', '2017-03-09 03:58:20'),
(68, 'Jamal DuBuque', 'rkertzmann@example.org', '$2y$10$Ohrj.SEBkG2jrcvA4p7AXOxxCAVYZPy9iuoJw.Th1J1kR21jxEgxm', 'gsXhX7WEI0', '2017-03-09 03:58:20', '2017-03-09 03:58:20'),
(69, 'Enid Bergstrom IV', 'ihansen@example.com', '$2y$10$Ohrj.SEBkG2jrcvA4p7AXOxxCAVYZPy9iuoJw.Th1J1kR21jxEgxm', 'SgvEbmaVPd', '2017-03-09 03:58:20', '2017-03-09 03:58:20'),
(70, 'Mr. Graham Mitchell', 'bergstrom.royal@example.net', '$2y$10$Ohrj.SEBkG2jrcvA4p7AXOxxCAVYZPy9iuoJw.Th1J1kR21jxEgxm', 'THo9kYJROz', '2017-03-09 03:58:20', '2017-03-09 03:58:20'),
(71, 'Vida DuBuque PhD', 'ferne.bradtke@example.net', '$2y$10$Ohrj.SEBkG2jrcvA4p7AXOxxCAVYZPy9iuoJw.Th1J1kR21jxEgxm', 'fOSu93za5i', '2017-03-09 03:58:20', '2017-03-09 03:58:20'),
(72, 'Effie Pollich Jr.', 'gino72@example.org', '$2y$10$Ohrj.SEBkG2jrcvA4p7AXOxxCAVYZPy9iuoJw.Th1J1kR21jxEgxm', '5MQwf5jyYX', '2017-03-09 03:58:20', '2017-03-09 03:58:20'),
(73, 'Mrs. Hosea Witting I', 'elnora91@example.net', '$2y$10$Ohrj.SEBkG2jrcvA4p7AXOxxCAVYZPy9iuoJw.Th1J1kR21jxEgxm', 'kivbRGmSZ3', '2017-03-09 03:58:20', '2017-03-09 03:58:20'),
(74, 'Cindy Hirthe', 'ebecker@example.net', '$2y$10$Ohrj.SEBkG2jrcvA4p7AXOxxCAVYZPy9iuoJw.Th1J1kR21jxEgxm', 'Ev6RWh6Z7o', '2017-03-09 03:58:20', '2017-03-09 03:58:20'),
(75, 'Chad Baumbach DVM', 'norberto.kertzmann@example.org', '$2y$10$Ohrj.SEBkG2jrcvA4p7AXOxxCAVYZPy9iuoJw.Th1J1kR21jxEgxm', 'q4iKb3O7Wz', '2017-03-09 03:58:20', '2017-03-09 03:58:20'),
(76, 'Dr. Garfield Kunze I', 'kirlin.fabiola@example.net', '$2y$10$Ohrj.SEBkG2jrcvA4p7AXOxxCAVYZPy9iuoJw.Th1J1kR21jxEgxm', 'AsLQbVEqUQ', '2017-03-09 03:58:20', '2017-03-09 03:58:20'),
(77, 'Alvina O\'Connell', 'graham.reilly@example.com', '$2y$10$Ohrj.SEBkG2jrcvA4p7AXOxxCAVYZPy9iuoJw.Th1J1kR21jxEgxm', 'GK2UOFQLIo', '2017-03-09 03:58:20', '2017-03-09 03:58:20'),
(78, 'Ignacio Parisian', 'dstanton@example.com', '$2y$10$Ohrj.SEBkG2jrcvA4p7AXOxxCAVYZPy9iuoJw.Th1J1kR21jxEgxm', 'GnrAdwKVj8', '2017-03-09 03:58:20', '2017-03-09 03:58:20'),
(79, 'Willow Altenwerth', 'haley.bergnaum@example.com', '$2y$10$Ohrj.SEBkG2jrcvA4p7AXOxxCAVYZPy9iuoJw.Th1J1kR21jxEgxm', '8J6KMn0n7L', '2017-03-09 03:58:20', '2017-03-09 03:58:20'),
(80, 'Hal Stoltenberg', 'diego.zieme@example.net', '$2y$10$Ohrj.SEBkG2jrcvA4p7AXOxxCAVYZPy9iuoJw.Th1J1kR21jxEgxm', 'YUzUv2BIDL', '2017-03-09 03:58:20', '2017-03-09 03:58:20'),
(81, 'Agustin Konopelski V', 'miller.darien@example.com', '$2y$10$Ohrj.SEBkG2jrcvA4p7AXOxxCAVYZPy9iuoJw.Th1J1kR21jxEgxm', '7VZmfAnPN3', '2017-03-09 03:58:20', '2017-03-09 03:58:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `permissions_inherit_id_index` (`inherit_id`),
  ADD KEY `permissions_name_index` (`name`),
  ADD KEY `permissions_slug_index` (`slug`);

--
-- Indexes for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD PRIMARY KEY (`id`),
  ADD KEY `permission_role_permission_id_index` (`permission_id`),
  ADD KEY `permission_role_role_id_index` (`role_id`);

--
-- Indexes for table `permission_user`
--
ALTER TABLE `permission_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `permission_user_permission_id_index` (`permission_id`),
  ADD KEY `permission_user_user_id_index` (`user_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`name`),
  ADD UNIQUE KEY `roles_slug_unique` (`slug`);

--
-- Indexes for table `role_user`
--
ALTER TABLE `role_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_user_role_id_index` (`role_id`),
  ADD KEY `role_user_user_id_index` (`user_id`);

--
-- Indexes for table `tbl_students`
--
ALTER TABLE `tbl_students`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `permission_role`
--
ALTER TABLE `permission_role`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `permission_user`
--
ALTER TABLE `permission_user`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `role_user`
--
ALTER TABLE `role_user`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbl_students`
--
ALTER TABLE `tbl_students`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `permissions`
--
ALTER TABLE `permissions`
  ADD CONSTRAINT `permissions_inherit_id_foreign` FOREIGN KEY (`inherit_id`) REFERENCES `permissions` (`id`);

--
-- Constraints for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
