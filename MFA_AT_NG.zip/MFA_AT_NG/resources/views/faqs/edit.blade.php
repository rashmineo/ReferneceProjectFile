@extends('adminlte::page')

@section('title','Edit FAQs')

@section('content_header')
    <h1>Manage FAQs</h1>
    <br />
    <a href="{{ url('/faqs') }}" title="Back"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>  
@stop
@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                
                <div class="panel-heading">Edit FAQ #{{ $faq->id }}</div>
                <div class="panel-body">
                {!! 

                Form::model($faq, [
                	'method' => 'PATCH',
                    'url' => ['/faqs', $faq->id],
                    'class' => 'form-horizontal',
                    'files' => true
                ])
                !!}
                @include ('faqs.form', ['submitButtonText' => 'Update'])

                        {!! Form::close() !!}
                </div>
            </div>    
		</div>
	</div>
</div>			


@endsection
