@extends('layouts.app')

@section('content')

<div class="row">
	<div class="col-md-6 col-md-offset-3">
		
		<h3>{{ $userall->count() }} Out of {{ $userall->total() }} Total Users</h3>
		<span>{{ $userall->currentPage() }} : currentPage</span>
		<span>{{ $userall->firstItem() }} : firstItem</span>
		<span>{{ $userall->hasMorePages() }} : hasMorePages</span>
		<span>{{ $userall->lastItem() }} : lastItem</span>
		<span>{{ $userall->nextPageUrl() }} : nextPageUrl</span>
		<span>{{ $userall->previousPageUrl() }} : previousPageUrl</span>
		<span>{{ $userall->perPage() }} : perPage</span>
		<ul class="list-group">
			@foreach($userall as $allusers)
			<li class="list-group-item" style="margin-top: 20px">
			<span>
				{{ $allusers->name }}
			</span>
			<span class="pull-right clearfix"> Joined
				{{ $allusers->created_at->diffForHumans() }}
				<button class="btn btn-xs btn-primary">Follow</button>
			</span>

			</li>
			@endforeach
			{{ $userall->links() }}
		</ul>
	</div>
</div>

@endsection
@foreach($users as $user)
<li>{!! $user['first_name'] !!}{!! $user['last_name'] !!}</li>
@endforeach

