<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Article extends Model
{
    //
    protected $fillable = [
    	'user_id', 'title', 'content', 'live', 'post_on',
    ];

    protected $guarded = ['id'];

    public function setLiveAttribute($value){
    	$this->attributes['live'] = (boolean)$value;
    } 
}
